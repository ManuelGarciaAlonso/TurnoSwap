	window.widgets = {
		descriptionMap : widgetDescriptionMap = {},
		rootWidgetMap : widgetRootMap = {}
	};

	widgets.descriptionMap[["s-Image", "2c8e25d0-cd1b-4da5-8d86-581cdeac9007"]] = ""; 

			widgets.rootWidgetMap[["s-Image", "2c8e25d0-cd1b-4da5-8d86-581cdeac9007"]] = ["Image", "s-Image"]; 

	widgets.descriptionMap[["s-Image", "e9ef1327-6215-4860-9c31-d6ecf5e0a15e"]] = ""; 

			widgets.rootWidgetMap[["s-Image", "e9ef1327-6215-4860-9c31-d6ecf5e0a15e"]] = ["Image", "s-Image"]; 

	widgets.descriptionMap[["s-Image", "4caeb18d-a9c2-4c51-9a76-551e4e4878e2"]] = ""; 

			widgets.rootWidgetMap[["s-Image", "4caeb18d-a9c2-4c51-9a76-551e4e4878e2"]] = ["Image", "s-Image"]; 

	widgets.descriptionMap[["s-Image", "b0789fab-6bd0-4f43-a0bf-f93b09d39171"]] = ""; 

			widgets.rootWidgetMap[["s-Image", "b0789fab-6bd0-4f43-a0bf-f93b09d39171"]] = ["Image", "s-Image"]; 

	widgets.descriptionMap[["s-Image", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Image", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Image", "s-Image"]; 

	