(function(window, undefined) {

  var jimLinks = {
    "2c8e25d0-cd1b-4da5-8d86-581cdeac9007" : {
      "Hotspot_1" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ],
      "Hotspot_2" : [
        "4caeb18d-a9c2-4c51-9a76-551e4e4878e2"
      ]
    },
    "e9ef1327-6215-4860-9c31-d6ecf5e0a15e" : {
      "Hotspot_1" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ],
      "Hotspot_2" : [
        "4caeb18d-a9c2-4c51-9a76-551e4e4878e2"
      ],
      "Hotspot_3" : [
        "2c8e25d0-cd1b-4da5-8d86-581cdeac9007"
      ],
      "Hotspot_4" : [
        "b0789fab-6bd0-4f43-a0bf-f93b09d39171"
      ],
      "Hotspot_5" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ]
    },
    "4caeb18d-a9c2-4c51-9a76-551e4e4878e2" : {
      "Hotspot_1" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ],
      "Hotspot_2" : [
        "2c8e25d0-cd1b-4da5-8d86-581cdeac9007"
      ],
      "Hotspot_3" : [
        "b0789fab-6bd0-4f43-a0bf-f93b09d39171"
      ]
    },
    "b0789fab-6bd0-4f43-a0bf-f93b09d39171" : {
      "Hotspot_1" : [
        "4caeb18d-a9c2-4c51-9a76-551e4e4878e2"
      ],
      "Hotspot_2" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ],
      "Hotspot_3" : [
        "4caeb18d-a9c2-4c51-9a76-551e4e4878e2"
      ],
      "Hotspot_4" : [
        "2c8e25d0-cd1b-4da5-8d86-581cdeac9007"
      ]
    },
    "d12245cc-1680-458d-89dd-4f0d7fb22724" : {
      "Hotspot_1" : [
        "4caeb18d-a9c2-4c51-9a76-551e4e4878e2"
      ],
      "Hotspot_2" : [
        "2c8e25d0-cd1b-4da5-8d86-581cdeac9007"
      ],
      "Hotspot_3" : [
        "e9ef1327-6215-4860-9c31-d6ecf5e0a15e"
      ]
    }    
  }

  window.jimLinks = jimLinks;
})(window);