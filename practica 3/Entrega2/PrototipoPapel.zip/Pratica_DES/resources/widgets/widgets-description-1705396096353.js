	window.widgets = {
		descriptionMap : widgetDescriptionMap = {},
		rootWidgetMap : widgetRootMap = {}
	};

	widgets.descriptionMap[["s-Image", "c750e81b-c8ef-4fa2-9325-8084c7e9746b"]] = ""; 

			widgets.rootWidgetMap[["s-Image", "c750e81b-c8ef-4fa2-9325-8084c7e9746b"]] = ["Image", "s-Image"]; 

	widgets.descriptionMap[["s-Image", "091eccff-ce7d-4120-8ffd-8939fa4baa38"]] = ""; 

			widgets.rootWidgetMap[["s-Image", "091eccff-ce7d-4120-8ffd-8939fa4baa38"]] = ["Image", "s-Image"]; 

	widgets.descriptionMap[["s-Image", "18960076-34a3-4977-8f71-a5afd0143169"]] = ""; 

			widgets.rootWidgetMap[["s-Image", "18960076-34a3-4977-8f71-a5afd0143169"]] = ["Image", "s-Image"]; 

	widgets.descriptionMap[["s-Image", "756a2b96-8f6d-4351-b368-3772724c6851"]] = ""; 

			widgets.rootWidgetMap[["s-Image", "756a2b96-8f6d-4351-b368-3772724c6851"]] = ["Image", "s-Image"]; 

	widgets.descriptionMap[["s-Image", "c8d0c6da-3bfc-41d5-b40e-b80fcafb89cb"]] = ""; 

			widgets.rootWidgetMap[["s-Image", "c8d0c6da-3bfc-41d5-b40e-b80fcafb89cb"]] = ["Image", "s-Image"]; 

	widgets.descriptionMap[["s-Image", "54690deb-c9a1-47a1-9823-132722658f95"]] = ""; 

			widgets.rootWidgetMap[["s-Image", "54690deb-c9a1-47a1-9823-132722658f95"]] = ["Image", "s-Image"]; 

	widgets.descriptionMap[["s-Image", "388077aa-3951-46ba-a6cc-8c880a1e878a"]] = ""; 

			widgets.rootWidgetMap[["s-Image", "388077aa-3951-46ba-a6cc-8c880a1e878a"]] = ["Image", "s-Image"]; 

	widgets.descriptionMap[["s-Image", "9a0f5cb8-dd34-4084-9a95-0e0651d0c97c"]] = ""; 

			widgets.rootWidgetMap[["s-Image", "9a0f5cb8-dd34-4084-9a95-0e0651d0c97c"]] = ["Image", "s-Image"]; 

	widgets.descriptionMap[["s-Image", "afce9ffd-04f5-496c-9ddc-e7277c376ec2"]] = ""; 

			widgets.rootWidgetMap[["s-Image", "afce9ffd-04f5-496c-9ddc-e7277c376ec2"]] = ["Image", "s-Image"]; 

	widgets.descriptionMap[["s-Image", "3805cab5-ed62-4adf-ba24-9c11027b86f1"]] = ""; 

			widgets.rootWidgetMap[["s-Image", "3805cab5-ed62-4adf-ba24-9c11027b86f1"]] = ["Image", "s-Image"]; 

	widgets.descriptionMap[["s-Image", "f1d836c8-943d-42ef-a56e-05e9c8082431"]] = ""; 

			widgets.rootWidgetMap[["s-Image", "f1d836c8-943d-42ef-a56e-05e9c8082431"]] = ["Image", "s-Image"]; 

	widgets.descriptionMap[["s-Image", "99eda379-2571-4517-8f52-2fc010507843"]] = ""; 

			widgets.rootWidgetMap[["s-Image", "99eda379-2571-4517-8f52-2fc010507843"]] = ["Image", "s-Image"]; 

	widgets.descriptionMap[["s-Image", "a8ad7155-29ac-4ad8-afa0-18ef2e7b0b25"]] = ""; 

			widgets.rootWidgetMap[["s-Image", "a8ad7155-29ac-4ad8-afa0-18ef2e7b0b25"]] = ["Image", "s-Image"]; 

	widgets.descriptionMap[["s-Image", "3603251b-8d94-4645-b971-4b9d6a770b76"]] = ""; 

			widgets.rootWidgetMap[["s-Image", "3603251b-8d94-4645-b971-4b9d6a770b76"]] = ["Image", "s-Image"]; 

	widgets.descriptionMap[["s-Image", "18963d99-ab54-405d-a7fd-54208b3c46f4"]] = ""; 

			widgets.rootWidgetMap[["s-Image", "18963d99-ab54-405d-a7fd-54208b3c46f4"]] = ["Image", "s-Image"]; 

	widgets.descriptionMap[["s-Image", "bb2be80d-78e0-4696-9a52-8b9564875ae7"]] = ""; 

			widgets.rootWidgetMap[["s-Image", "bb2be80d-78e0-4696-9a52-8b9564875ae7"]] = ["Image", "s-Image"]; 

	widgets.descriptionMap[["s-Image", "d7fecf91-8527-4df8-8503-b6cb0c8724e9"]] = ""; 

			widgets.rootWidgetMap[["s-Image", "d7fecf91-8527-4df8-8503-b6cb0c8724e9"]] = ["Image", "s-Image"]; 

	widgets.descriptionMap[["s-Image", "f648bcd0-db96-4b12-a562-b4ffe1cf4c0b"]] = ""; 

			widgets.rootWidgetMap[["s-Image", "f648bcd0-db96-4b12-a562-b4ffe1cf4c0b"]] = ["Image", "s-Image"]; 

	widgets.descriptionMap[["s-Image", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Image", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Image", "s-Image"]; 

	widgets.descriptionMap[["s-Image", "c74beaa4-6980-4c4f-99ac-6431b06936da"]] = ""; 

			widgets.rootWidgetMap[["s-Image", "c74beaa4-6980-4c4f-99ac-6431b06936da"]] = ["Image", "s-Image"]; 

	widgets.descriptionMap[["s-Image", "d21f3fc7-dfc7-4076-a756-d312913a1c80"]] = ""; 

			widgets.rootWidgetMap[["s-Image", "d21f3fc7-dfc7-4076-a756-d312913a1c80"]] = ["Image", "s-Image"]; 

	