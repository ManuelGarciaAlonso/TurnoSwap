var content='<div class="ui-page" deviceName="androidphone" deviceType="mobile" deviceWidth="360" deviceHeight="640">\
    <div id="t-f39803f7-df02-4169-93eb-7547fb8c961a" class="template growth-both devMobile devAndroid android-device canvas firer commentable non-processed" alignment="left" name="Template 1" width="360" height="640">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1705401896227.css" />\
      <div class="freeLayout">\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>\
    <div id="s-39dde134-b706-4824-b17d-7511961dacdb" class="screen growth-vertical devMobile devAndroid android-device canvas PORTRAIT firer ie-background commentable non-processed" alignment="left" name="perfil" width="360" height="640">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/screens/39dde134-b706-4824-b17d-7511961dacdb-1705401896227.css" />\
      <div class="freeLayout">\
      <div id="s-Image_3" class="image firer ie-background commentable non-processed" customid="logo - copia"   datasizewidth="35.0px" datasizeheight="50.0px" dataX="162.5" dataY="9.0"   alt="image">\
        <div class="borderLayer">\
        	<div class="imageViewport">\
        		<img src="./images/4923cd6b-837d-4014-b812-bd711b348f73.png" />\
        	</div>\
        </div>\
      </div>\
\
      <div id="s-Table_1" class="table firer commentable non-processed" customid="Table 1"  datasizewidth="292.3px" datasizeheight="466.4px" dataX="34.0" dataY="133.2" originalwidth="291.3333333333334px" originalheight="465.4px" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <table summary="">\
              <tbody>\
                <tr>\
                  <td id="s-Cell_1" customid="Cell 1" class="cellcontainer firer ie-background non-processed"    datasizewidth="292.3px" datasizeheight="94.6px" dataX="0.0" dataY="0.0" originalwidth="291.3333333333337px" originalheight="93.60337370242215px" >\
                    <div class="cellContainerChild">\
                      <div class="backgroundLayer">\
                        <div class="colorLayer"></div>\
                        <div class="imageLayer"></div>\
                      </div>\
                      <div class="borderLayer">\
                    	  <div class="layout scrollable">\
                    	    <div class="paddingLayer">\
                            <table class="layout" summary="">\
                              <tr>\
                                <td class="layout vertical insertionpoint verticalalign Cell_1 Table_1" valign="middle" align="center" hSpacing="0" vSpacing="0"></td> \
                              </tr>\
                            </table>\
\
                          </div>\
                        </div>\
                      </div>\
                    </div>\
                  </td>\
                </tr>\
                <tr>\
                  <td id="s-Cell_2" customid="Cell 2" class="cellcontainer firer ie-background non-processed"    datasizewidth="292.3px" datasizeheight="94.6px" dataX="0.0" dataY="0.0" originalwidth="291.3333333333337px" originalheight="93.60337370242215px" >\
                    <div class="cellContainerChild">\
                      <div class="backgroundLayer">\
                        <div class="colorLayer"></div>\
                        <div class="imageLayer"></div>\
                      </div>\
                      <div class="borderLayer">\
                    	  <div class="layout scrollable">\
                    	    <div class="paddingLayer">\
                            <table class="layout" summary="">\
                              <tr>\
                                <td class="layout vertical insertionpoint verticalalign Cell_2 Table_1" valign="middle" align="center" hSpacing="0" vSpacing="0"></td> \
                              </tr>\
                            </table>\
\
                          </div>\
                        </div>\
                      </div>\
                    </div>\
                  </td>\
                </tr>\
                <tr>\
                  <td id="s-Cell_3" customid="Cell 3" class="cellcontainer firer ie-background non-processed"    datasizewidth="292.3px" datasizeheight="93.7px" dataX="0.0" dataY="0.0" originalwidth="291.3333333333337px" originalheight="92.73108419838523px" >\
                    <div class="cellContainerChild">\
                      <div class="backgroundLayer">\
                        <div class="colorLayer"></div>\
                        <div class="imageLayer"></div>\
                      </div>\
                      <div class="borderLayer">\
                    	  <div class="layout scrollable">\
                    	    <div class="paddingLayer">\
                            <table class="layout" summary="">\
                              <tr>\
                                <td class="layout vertical insertionpoint verticalalign Cell_3 Table_1" valign="middle" align="center" hSpacing="0" vSpacing="0"></td> \
                              </tr>\
                            </table>\
\
                          </div>\
                        </div>\
                      </div>\
                    </div>\
                  </td>\
                </tr>\
                <tr>\
                  <td id="s-Cell_4" customid="Cell 4" class="cellcontainer firer ie-background non-processed"    datasizewidth="292.3px" datasizeheight="93.7px" dataX="0.0" dataY="0.0" originalwidth="291.3333333333337px" originalheight="92.73108419838523px" >\
                    <div class="cellContainerChild">\
                      <div class="backgroundLayer">\
                        <div class="colorLayer"></div>\
                        <div class="imageLayer"></div>\
                      </div>\
                      <div class="borderLayer">\
                    	  <div class="layout scrollable">\
                    	    <div class="paddingLayer">\
                            <table class="layout" summary="">\
                              <tr>\
                                <td class="layout vertical insertionpoint verticalalign Cell_4 Table_1" valign="middle" align="center" hSpacing="0" vSpacing="0"></td> \
                              </tr>\
                            </table>\
\
                          </div>\
                        </div>\
                      </div>\
                    </div>\
                  </td>\
                </tr>\
                <tr>\
                  <td id="s-Cell_5" customid="Cell 5" class="cellcontainer firer ie-background non-processed"    datasizewidth="292.3px" datasizeheight="93.7px" dataX="0.0" dataY="0.0" originalwidth="291.3333333333337px" originalheight="92.73108419838523px" >\
                    <div class="cellContainerChild">\
                      <div class="backgroundLayer">\
                        <div class="colorLayer"></div>\
                        <div class="imageLayer"></div>\
                      </div>\
                      <div class="borderLayer">\
                    	  <div class="layout scrollable">\
                    	    <div class="paddingLayer">\
                            <table class="layout" summary="">\
                              <tr>\
                                <td class="layout vertical insertionpoint verticalalign Cell_5 Table_1" valign="middle" align="center" hSpacing="0" vSpacing="0"></td> \
                              </tr>\
                            </table>\
\
                          </div>\
                        </div>\
                      </div>\
                    </div>\
                  </td>\
                </tr>\
              </tbody>\
            </table>\
          </div>\
        </div>\
      </div>\
      <div id="s-Path_42" class="path firer commentable non-processed" customid="Search"   datasizewidth="17.5px" datasizeheight="17.5px" dataX="40.0" dataY="111.0"  >\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg xmlns="http://www.w3.org/2000/svg" width="17.489999771118164" height="17.489999771118164" viewBox="40.0 111.0 17.489999771118164 17.489999771118164" preserveAspectRatio="none">\
          	  <g>\
          	    <defs>\
          	      <path id="s-Path_42-39dde" d="M52.5 122.0 L51.70999997854233 122.0 L51.429999977350235 121.72999998927116 C52.40999984741211 120.59000015258789 53.0 119.10999965667725 53.0 117.5 C53.0 113.90999984741211 50.09000015258789 111.0 46.5 111.0 C42.90999984741211 111.0 40.0 113.90999984741211 40.0 117.5 C40.0 121.09000015258789 42.90999984741211 124.0 46.5 124.0 C48.110000014305115 124.0 49.58999991416931 123.41000002622604 50.730000019073486 122.42999994754791 L51.00000002980232 122.70999994874 L51.00000002980232 123.49999997019768 L56.00000002980232 128.48999974131584 L57.489999771118164 127.0 L52.5 122.0 Z M46.5 122.0 C44.010000228881836 122.0 42.0 119.98999977111816 42.0 117.5 C42.0 115.01000022888184 44.010000228881836 113.0 46.5 113.0 C48.989999771118164 113.0 51.0 115.01000022888184 51.0 117.5 C51.0 119.98999977111816 48.989999771118164 122.0 46.5 122.0 Z "></path>\
          	    </defs>\
          	    <g style="mix-blend-mode:normal">\
          	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_42-39dde" fill="#7D7D7D" fill-opacity="1.0"></use>\
          	    </g>\
          	  </g>\
          	</svg>\
\
          </div>\
        </div>\
      </div>\
      <div id="s-Paragraph_1" class="richtext autofit firer ie-background commentable non-processed" customid="Ajustes"   datasizewidth="57.8px" datasizeheight="18.0px" dataX="64.0" dataY="110.7" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_1_0">Ajustes</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Paragraph_2" class="richtext autofit firer ie-background commentable non-processed" customid="Paragraph"   datasizewidth="1.0px" datasizeheight="1.0px" dataX="110.0" dataY="165.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_2_0"></span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Paragraph_3" class="richtext autofit firer ie-background commentable non-processed" customid="Pen&eacute;lope Cruz"   datasizewidth="165.4px" datasizeheight="28.0px" dataX="135.0" dataY="165.5" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_3_0">Pen&eacute;lope Cruz</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Paragraph_4" class="richtext autofit firer ie-background commentable non-processed" customid="Cuenta"   datasizewidth="80.6px" datasizeheight="28.0px" dataX="135.0" dataY="259.5" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_4_0">Cuenta</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Paragraph_5" class="richtext autofit firer ie-background commentable non-processed" customid="Notificaciones"   datasizewidth="155.6px" datasizeheight="28.0px" dataX="135.0" dataY="352.5" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_5_0">Notificaciones</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Paragraph_6" class="richtext autofit firer ie-background commentable non-processed" customid="Privacidad"   datasizewidth="116.7px" datasizeheight="28.0px" dataX="135.0" dataY="448.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_6_0">Privacidad</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Paragraph_7" class="richtext autofit firer ie-background commentable non-processed" customid="Ayuda"   datasizewidth="70.9px" datasizeheight="28.0px" dataX="135.0" dataY="536.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_7_0">Ayuda</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
\
      <div id="s-Image_4" class="image firer ie-background commentable non-processed" customid="Image 4"   datasizewidth="70.0px" datasizeheight="73.0px" dataX="44.8" dataY="143.0"   alt="image">\
        <div class="borderLayer">\
        	<div class="imageViewport">\
        		<img src="./images/7ca47c09-cfed-4144-bf31-3f623767085d.png" />\
        	</div>\
        </div>\
      </div>\
\
      <div id="s-Path_286" class="path firer commentable non-processed" customid="Secure"   datasizewidth="70.0px" datasizeheight="60.0px" dataX="44.8" dataY="432.0"  >\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg xmlns="http://www.w3.org/2000/svg" width="70.0" height="60.0" viewBox="44.82324218749996 432.0 70.0 60.0" preserveAspectRatio="none">\
          	  <g>\
          	    <defs>\
          	      <path id="s-Path_286-39dde" d="M81.89142279191447 452.0 C79.2823328538374 440.3500003814697 72.21869564056392 432.0 63.91415127840905 432.0 C53.38233327865596 432.0 44.82324218749996 445.4500002861023 44.82324218749996 462.0 C44.82324218749996 478.5499997138977 53.38233327865596 492.0 63.91415127840905 492.0 C72.2186963991685 492.0 79.2823328538374 483.6500002145767 81.89142430912361 472.0 L95.73233309659086 472.0 L95.73233309659086 492.0 L108.45960582386358 492.0 L108.45960582386358 472.0 L114.82324218749994 472.0 L114.82324218749994 452.0 L81.89142279191447 452.0 Z M63.91415127840905 472.0 C60.41415120254859 472.0 57.550514914772684 467.5000001192093 57.550514914772684 462.0 C57.550514914772684 456.4999998807907 60.41415120254859 452.0 63.91415127840905 452.0 C67.4141513542695 452.0 70.27778764204541 456.4999998807907 70.27778764204541 462.0 C70.27778764204541 467.5000001192093 67.4141513542695 472.0 63.91415127840905 472.0 Z "></path>\
          	    </defs>\
          	    <g style="mix-blend-mode:normal">\
          	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_286-39dde" fill="#11415A" fill-opacity="1.0"></use>\
          	    </g>\
          	  </g>\
          	</svg>\
\
          </div>\
        </div>\
      </div>\
      <div id="s-Path_176" class="path firer commentable non-processed" customid="Alert"   datasizewidth="70.0px" datasizeheight="70.0px" dataX="44.8" dataY="331.5"  >\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg xmlns="http://www.w3.org/2000/svg" width="70.0" height="70.0" viewBox="44.82324218749994 331.5 70.0 70.0" preserveAspectRatio="none">\
          	  <g>\
          	    <defs>\
          	      <path id="s-Path_176-39dde" d="M79.82324218749994 401.5 C84.63574229180807 401.5 88.57324218749994 398.2692308548169 88.57324218749994 394.3205128205128 L71.07324218749994 394.3205128205128 C71.07324218749994 398.2692308548169 74.96699212491507 401.5 79.82324218749994 401.5 Z M106.07324218749994 379.96153846153845 L106.07324218749994 362.0128205128205 C106.07324218749994 350.9923079319489 98.89824225008482 341.76666714594916 86.38574218749994 339.3256404094207 L86.38574218749994 336.88461538461536 C86.38574218749994 333.9051282650385 83.45449211448425 331.5 79.82324218749994 331.5 C76.19199226051563 331.5 73.26074218749994 333.9051282650385 73.26074218749994 336.88461538461536 L73.26074218749994 339.3256410513169 C60.70449268817896 341.76666714594916 53.57324218749994 350.95641053028595 53.57324218749994 362.0128205128205 L53.57324218749994 379.96153846153845 L44.82324218749994 387.14102564102564 L44.82324218749994 390.7307692307692 L114.82324218749994 390.7307692307692 L114.82324218749994 387.14102564102564 L106.07324218749994 379.96153846153845 Z "></path>\
          	    </defs>\
          	    <g style="mix-blend-mode:normal">\
          	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_176-39dde" fill="#11415A" fill-opacity="1.0"></use>\
          	    </g>\
          	  </g>\
          	</svg>\
\
          </div>\
        </div>\
      </div>\
      <div id="s-Path_8" class="path firer commentable non-processed" customid="Account_circle"   datasizewidth="70.0px" datasizeheight="70.0px" dataX="44.8" dataY="238.5"  >\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg xmlns="http://www.w3.org/2000/svg" width="70.0" height="70.0" viewBox="44.823242187499936 238.5 70.0 70.0" preserveAspectRatio="none">\
          	  <g>\
          	    <defs>\
          	      <path id="s-Path_8-39dde" d="M79.82324218749994 238.5 C60.50324225425714 238.5 44.823242187499936 254.1800000667572 44.823242187499936 273.5 C44.823242187499936 292.8199999332428 60.50324225425714 308.5 79.82324218749994 308.5 C99.14324212074274 308.5 114.82324218749994 292.8199999332428 114.82324218749994 273.5 C114.82324218749994 254.1800000667572 99.1432437896728 238.5 79.82324218749994 238.5 Z M79.82324218749994 249.0 C85.63324207067484 249.0 90.32324218749994 253.6900001168251 90.32324218749994 259.5 C90.32324218749994 265.3099998831749 85.63324207067484 270.0 79.82324218749994 270.0 C74.01324230432505 270.0 69.32324218749994 265.3099998831749 69.32324218749994 259.5 C69.32324218749994 253.6900001168251 74.01324230432505 249.0 79.82324218749994 249.0 Z M79.82324218749994 298.699999332428 C71.07324218749994 298.699999332428 63.33824205398553 294.2199994325638 58.823242187499936 287.4299992322922 C58.928242185153 280.4649991989136 72.82324218749994 276.649999499321 79.82324218749994 276.649999499321 C86.78824222087854 276.649999499321 100.71824145317072 280.4649996161461 100.82324218749994 287.4299992322922 C96.30824232101435 294.2199994325638 88.57324218749994 298.699999332428 79.82324218749994 298.699999332428 Z "></path>\
          	    </defs>\
          	    <g style="mix-blend-mode:normal">\
          	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_8-39dde" fill="#11415A" fill-opacity="1.0"></use>\
          	    </g>\
          	  </g>\
          	</svg>\
\
          </div>\
        </div>\
      </div>\
\
      <div id="s-Group_1" class="group firer ie-background commentable non-processed" customid="Group 1" datasizewidth="0.0px" datasizeheight="0.0px" >\
        <div id="s-Rectangle_1" class="rectangle manualfit firer commentable non-processed" customid="Rectangle 1"   datasizewidth="363.0px" datasizeheight="47.0px" datasizewidthpx="363.0000000432957" datasizeheightpx="47.0" dataX="-1.0" dataY="594.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Rectangle_1_0"></span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
\
        <div id="s-Image_1" class="image firer click ie-background commentable non-processed" customid="Image 1"   datasizewidth="50.4px" datasizeheight="47.0px" dataX="42.4" dataY="593.5"   alt="image">\
          <div class="borderLayer">\
          	<div class="imageViewport">\
          		<img src="./images/86da06ee-e2b7-435b-a167-c84b824d6989.png" />\
          	</div>\
          </div>\
        </div>\
\
\
        <div id="s-Image_2" class="image firer ie-background commentable non-processed" customid="Image 2"   datasizewidth="34.3px" datasizeheight="29.0px" dataX="163.4" dataY="603.0"   alt="image">\
          <div class="borderLayer">\
          	<div class="imageViewport">\
          		<img src="./images/20814eda-f2b3-40bf-9c8f-5146b39bd9ce.png" />\
          	</div>\
          </div>\
        </div>\
\
        <div id="s-Path_386" class="path firer commentable non-processed" customid="User"   datasizewidth="31.3px" datasizeheight="26.0px" dataX="280.3" dataY="604.0"  >\
          <div class="borderLayer">\
          	<div class="imageViewport">\
            	<?xml version="1.0" encoding="UTF-8"?>\
            	<svg xmlns="http://www.w3.org/2000/svg" width="31.25833511352539" height="26.0" viewBox="280.32500002660186 603.9999999999999 31.25833511352539 26.0" preserveAspectRatio="none">\
            	  <g>\
            	    <defs>\
            	      <path id="s-Path_386-39dde" d="M295.9541666951326 616.9999999999999 C300.2717240618399 616.9999999999999 303.76875002939795 614.0912500619887 303.76875002939795 610.4999999999999 C303.76875002939795 606.908749938011 300.2717240618399 603.9999999999999 295.9541666951326 603.9999999999999 C291.6366093284253 603.9999999999999 288.1395833608672 606.908749938011 288.1395833608672 610.4999999999999 C288.1395833608672 614.0912500619887 291.6366093284253 616.9999999999999 295.9541666951326 616.9999999999999 Z M295.9541666951326 620.2499999999999 C290.7379321704591 620.2499999999999 280.32500002660186 622.4275000542401 280.32500002660186 626.7499999999999 L280.32500002660186 629.9999999999999 L311.5833333636633 629.9999999999999 L311.5833333636633 626.7499999999999 C311.5833333636633 622.427499860525 301.1704012198061 620.2499999999999 295.9541666951326 620.2499999999999 Z "></path>\
            	    </defs>\
            	    <g style="mix-blend-mode:normal">\
            	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_386-39dde" fill="#000000" fill-opacity="1.0"></use>\
            	    </g>\
            	  </g>\
            	</svg>\
\
            </div>\
          </div>\
        </div>\
      </div>\
\
\
      <div id="s-Image_5" class="image firer ie-background commentable non-processed" customid="informacion"   datasizewidth="70.0px" datasizeheight="70.0px" dataX="44.8" dataY="515.0"   alt="image">\
        <div class="borderLayer">\
        	<div class="imageViewport">\
        		<img src="./images/c17d9f25-76f2-42a8-bf7a-33a6345eaf01.png" />\
        	</div>\
        </div>\
      </div>\
\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>  \
</div>\
';
document.getElementById("chromeTransfer").innerHTML = content;