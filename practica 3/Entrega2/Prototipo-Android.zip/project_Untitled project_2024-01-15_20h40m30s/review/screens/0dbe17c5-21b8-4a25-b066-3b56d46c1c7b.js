var content='<div class="ui-page" deviceName="androidphone" deviceType="mobile" deviceWidth="360" deviceHeight="640">\
    <div id="t-f39803f7-df02-4169-93eb-7547fb8c961a" class="template growth-both devMobile devAndroid android-device canvas firer commentable non-processed" alignment="left" name="Template 1" width="360" height="640">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1705401896227.css" />\
      <div class="freeLayout">\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>\
    <div id="s-0dbe17c5-21b8-4a25-b066-3b56d46c1c7b" class="screen growth-vertical devMobile devAndroid android-device canvas PORTRAIT firer ie-background commentable non-processed" alignment="left" name="cambioEsp2" width="360" height="640">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/screens/0dbe17c5-21b8-4a25-b066-3b56d46c1c7b-1705401896227.css" />\
      <div class="freeLayout">\
      <div id="s-Rectangle_4" class="rectangle manualfit firer commentable non-processed" customid="Rectangle 4"   datasizewidth="329.0px" datasizeheight="241.0px" datasizewidthpx="328.9999999999998" datasizeheightpx="241.0000000000001" dataX="14.0" dataY="354.5" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Rectangle_4_0"></span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Input_1" class="text firer commentable non-processed" customid="Input 1"  datasizewidth="291.0px" datasizeheight="32.0px" dataX="34.5" dataY="562.5" ><div class="backgroundLayer">\
        <div class="colorLayer"></div>\
        <div class="imageLayer"></div>\
      </div><div class="borderLayer"><div class="paddingLayer"><div class="content"><div class="valign"><input type="text"  value="" maxlength="100"  tabindex="-1" placeholder=""/></div></div>  </div></div></div>\
\
      <div id="s-Group_1" class="group firer ie-background commentable non-processed" customid="Group 1" datasizewidth="0.0px" datasizeheight="0.0px" >\
        <div id="s-Rectangle_1" class="rectangle manualfit firer commentable non-processed" customid="Rectangle 1"   datasizewidth="363.0px" datasizeheight="47.0px" datasizewidthpx="363.0000000432957" datasizeheightpx="47.0" dataX="-1.0" dataY="594.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Rectangle_1_0"></span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
\
        <div id="s-Image_1" class="image firer click ie-background commentable non-processed" customid="Image 1"   datasizewidth="50.4px" datasizeheight="47.0px" dataX="42.4" dataY="593.5"   alt="image">\
          <div class="borderLayer">\
          	<div class="imageViewport">\
          		<img src="./images/86da06ee-e2b7-435b-a167-c84b824d6989.png" />\
          	</div>\
          </div>\
        </div>\
\
\
        <div id="s-Image_2" class="image firer ie-background commentable non-processed" customid="Image 2"   datasizewidth="34.3px" datasizeheight="29.0px" dataX="163.4" dataY="603.0"   alt="image">\
          <div class="borderLayer">\
          	<div class="imageViewport">\
          		<img src="./images/20814eda-f2b3-40bf-9c8f-5146b39bd9ce.png" />\
          	</div>\
          </div>\
        </div>\
\
        <div id="s-Path_386" class="path firer click commentable non-processed" customid="User"   datasizewidth="31.3px" datasizeheight="26.0px" dataX="280.3" dataY="604.0"  >\
          <div class="borderLayer">\
          	<div class="imageViewport">\
            	<?xml version="1.0" encoding="UTF-8"?>\
            	<svg xmlns="http://www.w3.org/2000/svg" width="31.25833511352539" height="26.0" viewBox="280.32500002660186 603.9999999999999 31.25833511352539 26.0" preserveAspectRatio="none">\
            	  <g>\
            	    <defs>\
            	      <path id="s-Path_386-0dbe1" d="M295.9541666951326 616.9999999999999 C300.2717240618399 616.9999999999999 303.76875002939795 614.0912500619887 303.76875002939795 610.4999999999999 C303.76875002939795 606.908749938011 300.2717240618399 603.9999999999999 295.9541666951326 603.9999999999999 C291.6366093284253 603.9999999999999 288.1395833608672 606.908749938011 288.1395833608672 610.4999999999999 C288.1395833608672 614.0912500619887 291.6366093284253 616.9999999999999 295.9541666951326 616.9999999999999 Z M295.9541666951326 620.2499999999999 C290.7379321704591 620.2499999999999 280.32500002660186 622.4275000542401 280.32500002660186 626.7499999999999 L280.32500002660186 629.9999999999999 L311.5833333636633 629.9999999999999 L311.5833333636633 626.7499999999999 C311.5833333636633 622.427499860525 301.1704012198061 620.2499999999999 295.9541666951326 620.2499999999999 Z "></path>\
            	    </defs>\
            	    <g style="mix-blend-mode:normal">\
            	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_386-0dbe1" fill="#000000" fill-opacity="1.0"></use>\
            	    </g>\
            	  </g>\
            	</svg>\
\
            </div>\
          </div>\
        </div>\
      </div>\
\
\
      <div id="s-Image_3" class="image firer ie-background commentable non-processed" customid="logo - copia"   datasizewidth="35.0px" datasizeheight="50.0px" dataX="162.5" dataY="9.0"   alt="image">\
        <div class="borderLayer">\
        	<div class="imageViewport">\
        		<img src="./images/4923cd6b-837d-4014-b812-bd711b348f73.png" />\
        	</div>\
        </div>\
      </div>\
\
\
      <div id="s-Group_2" class="group firer ie-background commentable non-processed" customid="Group 2" datasizewidth="0.0px" datasizeheight="0.0px" >\
        <div id="s-Rectangle_2" class="rectangle manualfit firer commentable non-processed" customid="Rectangle 2"   datasizewidth="360.0px" datasizeheight="35.0px" datasizewidthpx="360.0" datasizeheightpx="35.0" dataX="0.0" dataY="79.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Rectangle_2_0"></span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Path_1" class="path firer click commentable non-processed" customid="Arrow Back"   datasizewidth="20.0px" datasizeheight="20.0px" dataX="12.0" dataY="86.5"  >\
          <div class="borderLayer">\
          	<div class="imageViewport">\
            	<?xml version="1.0" encoding="UTF-8"?>\
            	<svg xmlns="http://www.w3.org/2000/svg" width="20.0" height="20.0" viewBox="12.0 86.49999999999994 20.0 20.0" preserveAspectRatio="none">\
            	  <g>\
            	    <defs>\
            	      <path id="s-Path_1-0dbe1" d="M32.0 95.24999999999994 L16.78749990463257 95.24999999999994 L23.77500009536743 88.26249980926508 L22.0 86.49999999999994 L12.0 96.49999999999994 L22.0 106.49999999999994 L23.76249995827675 104.7375000417232 L16.78749990463257 97.74999999999994 L32.0 97.74999999999994 L32.0 95.24999999999994 Z "></path>\
            	    </defs>\
            	    <g style="mix-blend-mode:normal">\
            	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_1-0dbe1" fill="#FFFFFF" fill-opacity="1.0"></use>\
            	    </g>\
            	  </g>\
            	</svg>\
\
            </div>\
          </div>\
        </div>\
      </div>\
\
      <div id="s-Button_1" class="button multiline manualfit firer commentable non-processed" customid="Aceptar"   datasizewidth="150.0px" datasizeheight="45.0px" dataX="180.0" dataY="282.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Button_1_0">Aceptar</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Dynamic_Panel_1" class="dynamicpanel firer ie-background commentable non-processed" customid="Dynamic Panel 2" datasizewidth="291.0px" datasizeheight="137.0px" dataX="34.5" dataY="129.0" >\
        <div id="s-Panel_1" class="panel default firer ie-background commentable non-processed" customid="Panel 5"  datasizewidth="291.0px" datasizeheight="137.0px" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
          	<div class="layoutWrapper scrollable">\
          	  <div class="paddingLayer">\
                <div class="freeLayout">\
                <div id="s-Table_1" class="table firer commentable non-processed" customid="Table 1"  datasizewidth="291.0px" datasizeheight="138.0px" dataX="0.0" dataY="0.0" originalwidth="288.9999999999998px" originalheight="135.99999999999994px" >\
                  <div class="backgroundLayer">\
                    <div class="colorLayer"></div>\
                    <div class="imageLayer"></div>\
                  </div>\
                  <div class="borderLayer">\
                    <div class="paddingLayer">\
                      <table summary="">\
                        <tbody>\
                          <tr>\
                            <td id="s-Cell_1" customid="Cell 1" class="cellcontainer firer ie-background non-processed"    datasizewidth="291.0px" datasizeheight="138.0px" dataX="0.0" dataY="0.0" originalwidth="288.9999999999999px" originalheight="136.00000000000006px" >\
                              <div class="cellContainerChild">\
                                <div class="backgroundLayer">\
                                  <div class="colorLayer"></div>\
                                  <div class="imageLayer"></div>\
                                </div>\
                                <div class="borderLayer">\
                              	  <div class="layout scrollable">\
                              	    <div class="paddingLayer">\
                                      <table class="layout" summary="">\
                                        <tr>\
                                          <td class="layout vertical insertionpoint verticalalign Cell_1 Table_1" valign="middle" align="center" hSpacing="0" vSpacing="0"></td> \
                                        </tr>\
                                      </table>\
\
                                    </div>\
                                  </div>\
                                </div>\
                              </div>\
                            </td>\
                          </tr>\
                        </tbody>\
                      </table>\
                    </div>\
                  </div>\
                </div>\
                <div id="s-Paragraph_1" class="richtext manualfit firer ie-background commentable non-processed" customid="Intercambio de: Manuel Ji"   datasizewidth="141.4px" datasizeheight="36.0px" dataX="8.0" dataY="43.0" >\
                  <div class="backgroundLayer">\
                    <div class="colorLayer"></div>\
                    <div class="imageLayer"></div>\
                  </div>\
                  <div class="borderLayer">\
                    <div class="paddingLayer">\
                      <div class="content">\
                        <div class="valign">\
                          <span id="rtr-s-Paragraph_1_0">Intercambio de: </span><span id="rtr-s-Paragraph_1_1">Manuel Jimenez</span>\
                        </div>\
                      </div>\
                    </div>\
                  </div>\
                </div>\
                <div id="s-Paragraph_2" class="richtext autofit firer ie-background commentable non-processed" customid="18/01/2024"   datasizewidth="80.1px" datasizeheight="18.0px" dataX="8.0" dataY="9.0" >\
                  <div class="backgroundLayer">\
                    <div class="colorLayer"></div>\
                    <div class="imageLayer"></div>\
                  </div>\
                  <div class="borderLayer">\
                    <div class="paddingLayer">\
                      <div class="content">\
                        <div class="valign">\
                          <span id="rtr-s-Paragraph_2_0">18/01/2024</span>\
                        </div>\
                      </div>\
                    </div>\
                  </div>\
                </div>\
                <div id="s-Paragraph_4" class="richtext autofit firer ie-background commentable non-processed" customid="Preferencias17/01/2024"   datasizewidth="89.8px" datasizeheight="36.0px" dataX="190.0" dataY="7.0" >\
                  <div class="backgroundLayer">\
                    <div class="colorLayer"></div>\
                    <div class="imageLayer"></div>\
                  </div>\
                  <div class="borderLayer">\
                    <div class="paddingLayer">\
                      <div class="content">\
                        <div class="valign">\
                          <span id="rtr-s-Paragraph_4_0">Preferencias<br />17/01/2024</span>\
                        </div>\
                      </div>\
                    </div>\
                  </div>\
                </div>\
                <div id="s-Rectangle_3" class="rectangle manualfit firer commentable non-processed" customid="Rectangle 2"   datasizewidth="287.0px" datasizeheight="48.0px" datasizewidthpx="287.0" datasizeheightpx="48.0" dataX="1.0" dataY="87.0" >\
                  <div class="backgroundLayer">\
                    <div class="colorLayer"></div>\
                    <div class="imageLayer"></div>\
                  </div>\
                  <div class="borderLayer">\
                    <div class="paddingLayer">\
                      <div class="content">\
                        <div class="valign">\
                          <span id="rtr-s-Rectangle_3_0"></span>\
                        </div>\
                      </div>\
                    </div>\
                  </div>\
                </div>\
                <div id="s-Paragraph_6" class="richtext manualfit firer ie-background commentable non-processed" customid="Detalles: Tambi&eacute;n puedo c"   datasizewidth="267.7px" datasizeheight="36.0px" dataX="7.3" dataY="94.0" >\
                  <div class="backgroundLayer">\
                    <div class="colorLayer"></div>\
                    <div class="imageLayer"></div>\
                  </div>\
                  <div class="borderLayer">\
                    <div class="paddingLayer">\
                      <div class="content">\
                        <div class="valign">\
                          <span id="rtr-s-Paragraph_6_0">Detalles: </span><span id="rtr-s-Paragraph_6_1">Tambi&eacute;n puedo cambiar a partir del 25 de enero</span>\
                        </div>\
                      </div>\
                    </div>\
                  </div>\
                </div>\
                </div>\
\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Paragraph_3" class="richtext autofit firer ie-background commentable non-processed" customid="Chat con Manuel"   datasizewidth="128.0px" datasizeheight="18.0px" dataX="116.0" dataY="360.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_3_0">Chat con Manuel</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Rectangle_5" class="rectangle manualfit firer commentable non-processed" customid="Rectangle 5"   datasizewidth="212.0px" datasizeheight="34.0px" datasizewidthpx="212.0" datasizeheightpx="34.000000000000114" dataX="116.0" dataY="404.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Rectangle_5_0">Hola, &iquest;te viene bien el 10?</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Path_171" class="path firer commentable non-processed" customid="Send"   datasizewidth="21.0px" datasizeheight="18.0px" dataX="300.0" dataY="569.0"  >\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg xmlns="http://www.w3.org/2000/svg" width="21.0" height="18.0" viewBox="300.0 569.0 21.0 18.0" preserveAspectRatio="none">\
          	  <g>\
          	    <defs>\
          	      <path id="s-Path_171-0dbe1" d="M300.00999999046326 587.0 L321.0 578.0 L300.00999999046326 569.0 L300.0 576.0 L315.0 578.0 L300.0 580.0 Z "></path>\
          	    </defs>\
          	    <g style="mix-blend-mode:normal">\
          	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_171-0dbe1" fill="#7D7D7D" fill-opacity="1.0"></use>\
          	    </g>\
          	  </g>\
          	</svg>\
\
          </div>\
        </div>\
      </div>\
      <div id="s-Rectangle_6" class="rectangle manualfit firer commentable non-processed" customid="Rectangle 5"   datasizewidth="96.0px" datasizeheight="36.0px" datasizewidthpx="96.00000000000006" datasizeheightpx="36.000000000000114" dataX="24.0" dataY="457.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Rectangle_6_0">Creo que si</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Rectangle_7" class="rectangle manualfit firer commentable non-processed" customid="Rectangle 5"   datasizewidth="154.5px" datasizeheight="36.0px" datasizewidthpx="154.5" datasizeheightpx="36.0" dataX="24.0" dataY="501.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Rectangle_7_0">Ma&ntilde;ana te confirmo</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
\
      <div id="s-Group_3" class="group firer ie-background commentable non-processed" customid="Group 3" datasizewidth="0.0px" datasizeheight="0.0px" >\
        <div id="s-Rectangle_8" class="rectangle manualfit firer commentable non-processed" customid="Rectangle 8"   datasizewidth="200.0px" datasizeheight="179.0px" datasizewidthpx="200.00000000000023" datasizeheightpx="178.99999999999997" dataX="80.0" dataY="148.5" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Rectangle_8_0"></span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Paragraph_5" class="richtext manualfit firer ie-background commentable non-processed" customid="Introduzca la fecha por l"   datasizewidth="163.2px" datasizeheight="60.0px" dataX="98.4" dataY="165.7" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Paragraph_5_0">Introduzca la fecha por la que se cambia</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Input_2" class="date firer commentable non-processed" customid="Input 2" value="" format="MM/dd/yyyy"  datasizewidth="172.6px" datasizeheight="29.4px" dataX="93.7" dataY="234.2" ><div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div><div class="borderLayer"><div class="paddingLayer"><div class="content"><div class="valign"><input type="date"  tabindex="-1"  /></div></div></div></div></div>\
        <div id="s-Button_2" class="button multiline manualfit firer click commentable non-processed" customid="Aceptar"   datasizewidth="70.3px" datasizeheight="43.6px" dataX="196.0" dataY="274.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Button_2_0">Aceptar</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Button_3" class="button multiline manualfit firer click commentable non-processed" customid="Cancelar"   datasizewidth="70.3px" datasizeheight="43.6px" dataX="93.7" dataY="274.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Button_3_0">Cancelar</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>  \
</div>\
';
document.getElementById("chromeTransfer").innerHTML = content;