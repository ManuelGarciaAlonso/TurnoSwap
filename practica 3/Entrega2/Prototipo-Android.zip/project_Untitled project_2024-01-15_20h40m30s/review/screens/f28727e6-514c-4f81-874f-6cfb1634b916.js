var content='<div class="ui-page" deviceName="androidphone" deviceType="mobile" deviceWidth="360" deviceHeight="640">\
    <div id="t-f39803f7-df02-4169-93eb-7547fb8c961a" class="template growth-both devMobile devAndroid android-device canvas firer commentable non-processed" alignment="left" name="Template 1" width="360" height="640">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1705401896227.css" />\
      <div class="freeLayout">\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>\
    <div id="s-f28727e6-514c-4f81-874f-6cfb1634b916" class="screen growth-vertical devMobile devAndroid android-device canvas PORTRAIT firer ie-background commentable non-processed" alignment="left" name="AniadirCambios" width="360" height="640">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/screens/f28727e6-514c-4f81-874f-6cfb1634b916-1705401896227.css" />\
      <div class="freeLayout">\
      <div id="s-Group_1" class="group firer ie-background commentable non-processed" customid="Group 1" datasizewidth="0.0px" datasizeheight="0.0px" >\
        <div id="s-Rectangle_1" class="rectangle manualfit firer commentable non-processed" customid="Rectangle 1"   datasizewidth="363.0px" datasizeheight="47.0px" datasizewidthpx="363.0000000432957" datasizeheightpx="47.0" dataX="-1.0" dataY="594.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Rectangle_1_0"></span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
\
        <div id="s-Image_1" class="image firer click ie-background commentable non-processed" customid="Image 1"   datasizewidth="50.4px" datasizeheight="47.0px" dataX="42.4" dataY="593.5"   alt="image">\
          <div class="borderLayer">\
          	<div class="imageViewport">\
          		<img src="./images/86da06ee-e2b7-435b-a167-c84b824d6989.png" />\
          	</div>\
          </div>\
        </div>\
\
\
        <div id="s-Image_2" class="image firer ie-background commentable non-processed" customid="Image 2"   datasizewidth="34.3px" datasizeheight="29.0px" dataX="163.4" dataY="603.0"   alt="image">\
          <div class="borderLayer">\
          	<div class="imageViewport">\
          		<img src="./images/20814eda-f2b3-40bf-9c8f-5146b39bd9ce.png" />\
          	</div>\
          </div>\
        </div>\
\
        <div id="s-Path_386" class="path firer click commentable non-processed" customid="User"   datasizewidth="31.3px" datasizeheight="26.0px" dataX="280.3" dataY="604.0"  >\
          <div class="borderLayer">\
          	<div class="imageViewport">\
            	<?xml version="1.0" encoding="UTF-8"?>\
            	<svg xmlns="http://www.w3.org/2000/svg" width="31.25833511352539" height="26.0" viewBox="280.32500002660186 603.9999999999999 31.25833511352539 26.0" preserveAspectRatio="none">\
            	  <g>\
            	    <defs>\
            	      <path id="s-Path_386-f2872" d="M295.9541666951326 616.9999999999999 C300.2717240618399 616.9999999999999 303.76875002939795 614.0912500619887 303.76875002939795 610.4999999999999 C303.76875002939795 606.908749938011 300.2717240618399 603.9999999999999 295.9541666951326 603.9999999999999 C291.6366093284253 603.9999999999999 288.1395833608672 606.908749938011 288.1395833608672 610.4999999999999 C288.1395833608672 614.0912500619887 291.6366093284253 616.9999999999999 295.9541666951326 616.9999999999999 Z M295.9541666951326 620.2499999999999 C290.7379321704591 620.2499999999999 280.32500002660186 622.4275000542401 280.32500002660186 626.7499999999999 L280.32500002660186 629.9999999999999 L311.5833333636633 629.9999999999999 L311.5833333636633 626.7499999999999 C311.5833333636633 622.427499860525 301.1704012198061 620.2499999999999 295.9541666951326 620.2499999999999 Z "></path>\
            	    </defs>\
            	    <g style="mix-blend-mode:normal">\
            	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_386-f2872" fill="#000000" fill-opacity="1.0"></use>\
            	    </g>\
            	  </g>\
            	</svg>\
\
            </div>\
          </div>\
        </div>\
      </div>\
\
\
      <div id="s-Image_3" class="image firer ie-background commentable non-processed" customid="logo - copia"   datasizewidth="35.0px" datasizeheight="50.0px" dataX="162.5" dataY="9.0"   alt="image">\
        <div class="borderLayer">\
        	<div class="imageViewport">\
        		<img src="./images/4923cd6b-837d-4014-b812-bd711b348f73.png" />\
        	</div>\
        </div>\
      </div>\
\
\
      <div id="s-Group_2" class="group firer ie-background commentable non-processed" customid="Group 2" datasizewidth="0.0px" datasizeheight="0.0px" >\
        <div id="s-Rectangle_2" class="rectangle manualfit firer commentable non-processed" customid="Rectangle 2"   datasizewidth="360.0px" datasizeheight="35.0px" datasizewidthpx="360.0" datasizeheightpx="35.0" dataX="0.0" dataY="79.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Rectangle_2_0"></span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Path_1" class="path firer click commentable non-processed" customid="Arrow Back"   datasizewidth="20.0px" datasizeheight="20.0px" dataX="12.0" dataY="86.5"  >\
          <div class="borderLayer">\
          	<div class="imageViewport">\
            	<?xml version="1.0" encoding="UTF-8"?>\
            	<svg xmlns="http://www.w3.org/2000/svg" width="20.0" height="20.0" viewBox="12.0 86.49999999999994 20.0 20.0" preserveAspectRatio="none">\
            	  <g>\
            	    <defs>\
            	      <path id="s-Path_1-f2872" d="M32.0 95.24999999999994 L16.78749990463257 95.24999999999994 L23.77500009536743 88.26249980926508 L22.0 86.49999999999994 L12.0 96.49999999999994 L22.0 106.49999999999994 L23.76249995827675 104.7375000417232 L16.78749990463257 97.74999999999994 L32.0 97.74999999999994 L32.0 95.24999999999994 Z "></path>\
            	    </defs>\
            	    <g style="mix-blend-mode:normal">\
            	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_1-f2872" fill="#FFFFFF" fill-opacity="1.0"></use>\
            	    </g>\
            	  </g>\
            	</svg>\
\
            </div>\
          </div>\
        </div>\
      </div>\
\
      <div id="s-Input_1" class="text firer commentable non-processed" customid="Input 1"  datasizewidth="293.0px" datasizeheight="45.0px" dataX="33.5" dataY="462.5" ><div class="backgroundLayer">\
        <div class="colorLayer"></div>\
        <div class="imageLayer"></div>\
      </div><div class="borderLayer"><div class="paddingLayer"><div class="content"><div class="valign"><input type="text"  value="" maxlength="100"  tabindex="-1" placeholder=""/></div></div>  </div></div></div>\
      <div id="s-Paragraph_1" class="richtext manualfit firer ie-background commentable non-processed" customid="A&ntilde;adir una oferta de turn"   datasizewidth="258.0px" datasizeheight="44.0px" dataX="33.5" dataY="132.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_1_0">A&ntilde;adir una oferta de turno:</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Input_2" class="date firer commentable non-processed" customid="Input 2" value="" format="MM/dd/yyyy"  datasizewidth="293.0px" datasizeheight="45.0px" dataX="33.5" dataY="201.0" ><div class="backgroundLayer">\
        <div class="colorLayer"></div>\
        <div class="imageLayer"></div>\
      </div><div class="borderLayer"><div class="paddingLayer"><div class="content"><div class="valign"><input type="date"  tabindex="-1"  /></div></div></div></div></div>\
      <div id="s-Category_1" class="dropdown firer commentable non-processed" customid="Category 1"    datasizewidth="293.0px" datasizeheight="45.0px" dataX="33.5" dataY="282.5"  tabindex="-1"><div class="backgroundLayer">\
        <div class="colorLayer"></div>\
        <div class="imageLayer"></div>\
      </div><div class="borderLayer"><div class="paddingLayer"><div class="content icon"><div class="valign"><div class="value">Cambio</div></div></div></div></div><select id="s-Category_1-options" class="s-f28727e6-514c-4f81-874f-6cfb1634b916 dropdown-options" ><option selected="selected" class="option">Cambio</option>\
      <option  class="option">Venta</option></select></div>\
      <div id="s-Paragraph_2" class="richtext autofit firer ie-background commentable non-processed" customid="Fecha"   datasizewidth="44.5px" datasizeheight="18.0px" dataX="33.5" dataY="170.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_2_0">Fecha</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Paragraph_3" class="richtext autofit firer ie-background commentable non-processed" customid="Tipo de oferta:"   datasizewidth="103.2px" datasizeheight="18.0px" dataX="34.0" dataY="252.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_3_0">Tipo de oferta:</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Input_3" class="date firer commentable non-processed" customid="Input 2" value="" format="MM/dd/yyyy"  datasizewidth="293.0px" datasizeheight="45.0px" dataX="33.5" dataY="380.0" ><div class="backgroundLayer">\
        <div class="colorLayer"></div>\
        <div class="imageLayer"></div>\
      </div><div class="borderLayer"><div class="paddingLayer"><div class="content"><div class="valign"><input type="date"  tabindex="-1"  /></div></div></div></div></div>\
      <div id="s-Paragraph_4" class="richtext manualfit firer ie-background commentable non-processed" customid="Si es un cambio, &iquest;qu&eacute; fec"   datasizewidth="293.0px" datasizeheight="36.0px" dataX="33.5" dataY="336.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_4_0">Si es un cambio, &iquest;qu&eacute; fechas te gustar&iacute;an?</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Paragraph_5" class="richtext autofit firer ie-background commentable non-processed" customid="Descripci&oacute;n"   datasizewidth="83.6px" datasizeheight="18.0px" dataX="33.5" dataY="432.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_5_0">Descripci&oacute;n</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Button_1" class="button multiline manualfit firer click commentable non-processed" customid="Guardar"   datasizewidth="150.0px" datasizeheight="45.0px" dataX="180.0" dataY="530.3" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Button_1_0">Guardar</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>  \
</div>\
';
document.getElementById("chromeTransfer").innerHTML = content;