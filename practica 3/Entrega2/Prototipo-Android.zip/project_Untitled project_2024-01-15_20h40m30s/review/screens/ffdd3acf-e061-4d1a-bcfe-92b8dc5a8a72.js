var content='<div class="ui-page" deviceName="androidphone" deviceType="mobile" deviceWidth="360" deviceHeight="640">\
    <div id="t-f39803f7-df02-4169-93eb-7547fb8c961a" class="template growth-both devMobile devAndroid android-device canvas firer commentable non-processed" alignment="left" name="Template 1" width="360" height="640">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1705401896227.css" />\
      <div class="freeLayout">\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>\
    <div id="s-ffdd3acf-e061-4d1a-bcfe-92b8dc5a8a72" class="screen growth-vertical devMobile devAndroid android-device canvas PORTRAIT firer ie-background commentable non-processed" alignment="left" name="CrearGrup" width="360" height="640">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/screens/ffdd3acf-e061-4d1a-bcfe-92b8dc5a8a72-1705401896227.css" />\
      <div class="freeLayout">\
      <div id="s-Button_1" class="button multiline manualfit firer click commentable non-processed" customid="Siguiente"   datasizewidth="94.0px" datasizeheight="45.0px" dataX="244.0" dataY="579.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Button_1_0">Siguiente</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Input_2" class="text firer commentable non-processed" customid="Input 1"  datasizewidth="300.0px" datasizeheight="45.0px" dataX="30.0" dataY="303.5" ><div class="backgroundLayer">\
        <div class="colorLayer"></div>\
        <div class="imageLayer"></div>\
      </div><div class="borderLayer"><div class="paddingLayer"><div class="content"><div class="valign"><input type="text"  value="" maxlength="100"  tabindex="-1" placeholder="Nombre de plantilla"/></div></div>  </div></div></div>\
      <div id="s-Paragraph_1" class="richtext manualfit firer ie-background commentable non-processed" customid="C&oacute;digo de plantilla: ABCD"   datasizewidth="248.6px" datasizeheight="29.0px" dataX="30.0" dataY="252.5" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_1_0">C&oacute;digo de plantilla: ABCD</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Path_173" class="path firer commentable non-processed" customid="Share"   datasizewidth="18.0px" datasizeheight="19.9px" dataX="312.0" dataY="366.0"  >\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg xmlns="http://www.w3.org/2000/svg" width="18.0" height="19.920000076293945" viewBox="312.0000000000001 366.00000005960464 18.0 19.920000076293945" preserveAspectRatio="none">\
          	  <g>\
          	    <defs>\
          	      <path id="s-Path_173-ffdd3" d="M327.0000000000001 380.0800002217293 C326.24000000953686 380.0800002217293 325.55999994277965 380.3800002336502 325.03999996185314 380.8500002026558 L317.9099998474122 376.70000010728836 C317.9599998481573 376.47000010311604 317.9999998509885 376.2400000989437 317.9999998509885 376.0000001192093 C317.9999998509885 375.76000013947487 317.95999985188257 375.5300001204014 317.9099998474122 375.3000001311302 L324.9600000381471 371.1899999976158 C325.50000005960476 371.6899999976158 326.2100000381471 372.0 327.0000000000001 372.0 C328.6599999666215 372.0 330.0000000000001 370.6599999666214 330.0000000000001 369.0 C330.0000000000001 367.3400000333786 328.6599999666215 366.0 327.0000000000001 366.0 C325.3400000333787 366.0 324.0000000000001 367.3400000333786 324.0000000000001 369.0 C324.0000000000001 369.2399999946356 324.03999999910604 369.4699999988079 324.0900000035764 369.69999998807907 L317.03999996185314 373.8100007176399 C316.5000000000001 373.3100007176399 315.78999996185314 373.0000002980232 315.0000000000001 373.0000002980232 C313.3400000333787 373.0000002980232 312.0000000000001 374.3400003314018 312.0000000000001 376.0000002980232 C312.0000000000001 377.6600002646446 313.3400000333787 379.0000002980232 315.0000000000001 379.0000002980232 C315.7900000214578 379.0000002980232 316.5000000000001 378.69000029563904 317.03999996185314 378.19000029563904 L324.1599998474122 382.35000014305115 C324.10999984666717 382.56000013649464 324.07999984920036 382.7800001502037 324.07999984920036 383.0000001192093 C324.07999984920036 384.6100001335144 325.3899997919799 385.92000019550323 326.9999999254943 385.92000019550323 C328.6099999397994 385.92000019550323 329.92000000178825 384.6100002527237 329.92000000178825 383.0000001192093 C329.92000000178825 381.3899999856949 328.6100000590087 380.08000004291534 326.9999999254943 380.08000004291534 Z "></path>\
          	    </defs>\
          	    <g style="mix-blend-mode:normal">\
          	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_173-ffdd3" fill="#104057" fill-opacity="1.0"></use>\
          	    </g>\
          	  </g>\
          	</svg>\
\
          </div>\
        </div>\
      </div>\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>  \
</div>\
';
document.getElementById("chromeTransfer").innerHTML = content;