var content='<div class="ui-page" deviceName="androidphone" deviceType="mobile" deviceWidth="360" deviceHeight="640">\
    <div id="t-f39803f7-df02-4169-93eb-7547fb8c961a" class="template growth-both devMobile devAndroid android-device canvas firer commentable non-processed" alignment="left" name="Template 1" width="360" height="640">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1705401896227.css" />\
      <div class="freeLayout">\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>\
    <div id="s-e98dc6e4-1e98-4487-9027-5fda9eb217e7" class="screen growth-vertical devMobile devAndroid android-device canvas PORTRAIT firer ie-background commentable non-processed" alignment="left" name="cambios" width="360" height="640">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/screens/e98dc6e4-1e98-4487-9027-5fda9eb217e7-1705401896227.css" />\
      <div class="freeLayout">\
      <div id="s-Group_1" class="group firer ie-background commentable non-processed" customid="Group 1" datasizewidth="0.0px" datasizeheight="0.0px" >\
        <div id="s-Rectangle_1" class="rectangle manualfit firer commentable non-processed" customid="Rectangle 1"   datasizewidth="363.0px" datasizeheight="47.0px" datasizewidthpx="363.0000000432957" datasizeheightpx="47.0" dataX="-1.0" dataY="594.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Rectangle_1_0"></span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
\
        <div id="s-Image_1" class="image firer click ie-background commentable non-processed" customid="Image 1"   datasizewidth="50.4px" datasizeheight="47.0px" dataX="42.4" dataY="593.5"   alt="image">\
          <div class="borderLayer">\
          	<div class="imageViewport">\
          		<img src="./images/86da06ee-e2b7-435b-a167-c84b824d6989.png" />\
          	</div>\
          </div>\
        </div>\
\
\
        <div id="s-Image_2" class="image firer ie-background commentable non-processed" customid="Image 2"   datasizewidth="34.3px" datasizeheight="29.0px" dataX="163.4" dataY="603.0"   alt="image">\
          <div class="borderLayer">\
          	<div class="imageViewport">\
          		<img src="./images/20814eda-f2b3-40bf-9c8f-5146b39bd9ce.png" />\
          	</div>\
          </div>\
        </div>\
\
        <div id="s-Path_386" class="path firer click commentable non-processed" customid="User"   datasizewidth="31.3px" datasizeheight="26.0px" dataX="280.3" dataY="604.0"  >\
          <div class="borderLayer">\
          	<div class="imageViewport">\
            	<?xml version="1.0" encoding="UTF-8"?>\
            	<svg xmlns="http://www.w3.org/2000/svg" width="31.25833511352539" height="26.0" viewBox="280.32500002660186 603.9999999999999 31.25833511352539 26.0" preserveAspectRatio="none">\
            	  <g>\
            	    <defs>\
            	      <path id="s-Path_386-e98dc" d="M295.9541666951326 616.9999999999999 C300.2717240618399 616.9999999999999 303.76875002939795 614.0912500619887 303.76875002939795 610.4999999999999 C303.76875002939795 606.908749938011 300.2717240618399 603.9999999999999 295.9541666951326 603.9999999999999 C291.6366093284253 603.9999999999999 288.1395833608672 606.908749938011 288.1395833608672 610.4999999999999 C288.1395833608672 614.0912500619887 291.6366093284253 616.9999999999999 295.9541666951326 616.9999999999999 Z M295.9541666951326 620.2499999999999 C290.7379321704591 620.2499999999999 280.32500002660186 622.4275000542401 280.32500002660186 626.7499999999999 L280.32500002660186 629.9999999999999 L311.5833333636633 629.9999999999999 L311.5833333636633 626.7499999999999 C311.5833333636633 622.427499860525 301.1704012198061 620.2499999999999 295.9541666951326 620.2499999999999 Z "></path>\
            	    </defs>\
            	    <g style="mix-blend-mode:normal">\
            	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_386-e98dc" fill="#000000" fill-opacity="1.0"></use>\
            	    </g>\
            	  </g>\
            	</svg>\
\
            </div>\
          </div>\
        </div>\
      </div>\
\
\
      <div id="s-Image_3" class="image firer ie-background commentable non-processed" customid="logo - copia"   datasizewidth="35.0px" datasizeheight="50.0px" dataX="162.5" dataY="9.0"   alt="image">\
        <div class="borderLayer">\
        	<div class="imageViewport">\
        		<img src="./images/4923cd6b-837d-4014-b812-bd711b348f73.png" />\
        	</div>\
        </div>\
      </div>\
\
      <div id="s-Dynamic_Panel_1" class="dynamicpanel firer ie-background commentable non-processed" customid="Primary tabs text" datasizewidth="360.0px" datasizeheight="51.0px" dataX="0.0" dataY="84.0" >\
        <div id="s-Panel_1" class="panel default firer ie-background commentable non-processed" customid="Panel"  datasizewidth="360.0px" datasizeheight="51.0px" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
          	<div class="layoutWrapper scrollable">\
          	  <div class="paddingLayer">\
                <div class="freeLayout">\
                <div id="s-Rectangle_6" class="rectangle manualfit firer commentable non-processed" customid="BG"   datasizewidth="360.0px" datasizeheight="47.5px" datasizewidthpx="360.0" datasizeheightpx="47.5" dataX="0.0" dataY="1.0" >\
                  <div class="backgroundLayer">\
                    <div class="colorLayer"></div>\
                    <div class="imageLayer"></div>\
                  </div>\
                  <div class="borderLayer">\
                    <div class="paddingLayer">\
                      <div class="content">\
                        <div class="valign">\
                          <span id="rtr-s-Rectangle_6_0"></span>\
                        </div>\
                      </div>\
                    </div>\
                  </div>\
                </div>\
                <div id="s-Rectangle_8" class="rectangle manualfit firer click commentable non-processed" customid="Tab 2"   datasizewidth="145.0px" datasizeheight="42.0px" datasizewidthpx="144.99999999999977" datasizeheightpx="42.0" dataX="202.0" dataY="8.0" >\
                  <div class="backgroundLayer">\
                    <div class="colorLayer"></div>\
                    <div class="imageLayer"></div>\
                  </div>\
                  <div class="borderLayer">\
                    <div class="paddingLayer">\
                      <div class="content">\
                        <div class="valign">\
                          <span id="rtr-s-Rectangle_8_0">Otros cambios</span>\
                        </div>\
                      </div>\
                    </div>\
                  </div>\
                </div>\
                <div id="s-Rectangle_9" class="rectangle manualfit firer ie-background commentable non-processed" customid="Tab 1"   datasizewidth="142.1px" datasizeheight="35.0px" datasizewidthpx="142.0682817732859" datasizeheightpx="35.0" dataX="33.0" dataY="8.0" >\
                  <div class="backgroundLayer">\
                    <div class="colorLayer"></div>\
                    <div class="imageLayer"></div>\
                  </div>\
                  <div class="borderLayer">\
                    <div class="paddingLayer">\
                      <div class="content">\
                        <div class="valign">\
                          <span id="rtr-s-Rectangle_9_0">Tus Cambios</span>\
                        </div>\
                      </div>\
                    </div>\
                  </div>\
                </div>\
                <div id="s-Rectangle_10" class="rectangle manualfit firer commentable non-processed" customid="Select tab"   datasizewidth="45.0px" datasizeheight="3.0px" datasizewidthpx="45.0" datasizeheightpx="3.0" dataX="73.9" dataY="46.0" >\
                  <div class="backgroundLayer">\
                    <div class="colorLayer"></div>\
                    <div class="imageLayer"></div>\
                  </div>\
                  <div class="borderLayer">\
                    <div class="paddingLayer">\
                      <div class="content">\
                        <div class="valign">\
                          <span id="rtr-s-Rectangle_10_0"></span>\
                        </div>\
                      </div>\
                    </div>\
                  </div>\
                </div>\
                </div>\
\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Dynamic_Panel_2" class="dynamicpanel firer ie-background commentable non-processed" customid="Dynamic Panel 2" datasizewidth="291.0px" datasizeheight="363.0px" dataX="34.0" dataY="197.0" >\
        <div id="s-Panel_3" class="panel default firer ie-background commentable non-processed" customid="Panel 3"  datasizewidth="291.0px" datasizeheight="363.0px" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
          	<div class="layoutWrapper scrollable">\
          	  <div class="paddingLayer">\
                <div class="freeLayout">\
                <div id="s-Table_1" class="table firer commentable non-processed" customid="Table 1"  datasizewidth="291.0px" datasizeheight="209.0px" dataX="-0.0" dataY="0.0" originalwidth="288.99999999999983px" originalheight="206.99999999999994px" >\
                  <div class="backgroundLayer">\
                    <div class="colorLayer"></div>\
                    <div class="imageLayer"></div>\
                  </div>\
                  <div class="borderLayer">\
                    <div class="paddingLayer">\
                      <table summary="">\
                        <tbody>\
                          <tr>\
                            <td id="s-Cell_1" customid="Cell 1" class="cellcontainer firer ie-background non-processed"    datasizewidth="291.0px" datasizeheight="105.5px" dataX="0.0" dataY="0.0" originalwidth="288.99999999999994px" originalheight="103.5px" >\
                              <div class="cellContainerChild">\
                                <div class="backgroundLayer">\
                                  <div class="colorLayer"></div>\
                                  <div class="imageLayer"></div>\
                                </div>\
                                <div class="borderLayer">\
                              	  <div class="layout scrollable">\
                              	    <div class="paddingLayer">\
                                      <table class="layout" summary="">\
                                        <tr>\
                                          <td class="layout vertical insertionpoint verticalalign Cell_1 Table_1" valign="middle" align="center" hSpacing="0" vSpacing="0"></td> \
                                        </tr>\
                                      </table>\
\
                                    </div>\
                                  </div>\
                                </div>\
                              </div>\
                            </td>\
                          </tr>\
                          <tr>\
                            <td id="s-Cell_2" customid="Cell 2" class="cellcontainer firer ie-background non-processed"    datasizewidth="291.0px" datasizeheight="105.5px" dataX="0.0" dataY="0.0" originalwidth="288.99999999999994px" originalheight="103.5px" >\
                              <div class="cellContainerChild">\
                                <div class="backgroundLayer">\
                                  <div class="colorLayer"></div>\
                                  <div class="imageLayer"></div>\
                                </div>\
                                <div class="borderLayer">\
                              	  <div class="layout scrollable">\
                              	    <div class="paddingLayer">\
                                      <table class="layout" summary="">\
                                        <tr>\
                                          <td class="layout vertical insertionpoint verticalalign Cell_2 Table_1" valign="middle" align="center" hSpacing="0" vSpacing="0"></td> \
                                        </tr>\
                                      </table>\
\
                                    </div>\
                                  </div>\
                                </div>\
                              </div>\
                            </td>\
                          </tr>\
                        </tbody>\
                      </table>\
                    </div>\
                  </div>\
                </div>\
                <div id="s-Paragraph_1" class="richtext autofit firer ie-background commentable non-processed" customid="23/01/2024"   datasizewidth="80.1px" datasizeheight="18.0px" dataX="9.0" dataY="8.0" >\
                  <div class="backgroundLayer">\
                    <div class="colorLayer"></div>\
                    <div class="imageLayer"></div>\
                  </div>\
                  <div class="borderLayer">\
                    <div class="paddingLayer">\
                      <div class="content">\
                        <div class="valign">\
                          <span id="rtr-s-Paragraph_1_0">23/01/2024</span>\
                        </div>\
                      </div>\
                    </div>\
                  </div>\
                </div>\
                <div id="s-Paragraph_2" class="richtext autofit firer ie-background commentable non-processed" customid="Intercambio"   datasizewidth="83.6px" datasizeheight="18.0px" dataX="13.0" dataY="78.0" >\
                  <div class="backgroundLayer">\
                    <div class="colorLayer"></div>\
                    <div class="imageLayer"></div>\
                  </div>\
                  <div class="borderLayer">\
                    <div class="paddingLayer">\
                      <div class="content">\
                        <div class="valign">\
                          <span id="rtr-s-Paragraph_2_0">Intercambio</span>\
                        </div>\
                      </div>\
                    </div>\
                  </div>\
                </div>\
                <div id="s-Button_1" class="button multiline manualfit firer commentable non-processed" customid="Quitar"   datasizewidth="71.0px" datasizeheight="23.0px" dataX="207.0" dataY="74.5" >\
                  <div class="backgroundLayer">\
                    <div class="colorLayer"></div>\
                    <div class="imageLayer"></div>\
                  </div>\
                  <div class="borderLayer">\
                    <div class="paddingLayer">\
                      <div class="content">\
                        <div class="valign">\
                          <span id="rtr-s-Button_1_0">Quitar</span>\
                        </div>\
                      </div>\
                    </div>\
                  </div>\
                </div>\
                <div id="s-Path_197" class="path firer click commentable non-processed" customid="Add Circle Outline"   datasizewidth="35.0px" datasizeheight="35.0px" dataX="256.0" dataY="328.0"  >\
                  <div class="borderLayer">\
                  	<div class="imageViewport">\
                    	<?xml version="1.0" encoding="UTF-8"?>\
                    	<svg xmlns="http://www.w3.org/2000/svg" width="35.0" height="35.0" viewBox="255.99999999999977 328.0 35.0 35.0" preserveAspectRatio="none">\
                    	  <g>\
                    	    <defs>\
                    	      <path id="s-Path_197-e98dc" d="M275.2499999999998 336.75 L271.7499999999998 336.75 L271.7499999999998 343.75 L264.7499999999998 343.75 L264.7499999999998 347.25 L271.7499999999998 347.25 L271.7499999999998 354.25 L275.2499999999998 354.25 L275.2499999999998 347.25 L282.2499999999998 347.25 L282.2499999999998 343.75 L275.2499999999998 343.75 L275.2499999999998 336.75 Z M273.4999999999998 328.0 C263.8400000333784 328.0 255.99999999999977 335.8400000333786 255.99999999999977 345.5 C255.99999999999977 355.1599999666214 263.8400000333784 363.0 273.4999999999998 363.0 C283.15999996662117 363.0 290.9999999999998 355.1599999666214 290.9999999999998 345.5 C290.9999999999998 335.8400000333786 283.1600008010862 328.0 273.4999999999998 328.0 Z M273.4999999999998 359.5 C265.7825002670286 359.5 259.4999999999998 353.2175001502037 259.4999999999998 345.5 C259.4999999999998 337.7824998497963 265.78249984979607 331.5 273.4999999999998 331.5 C281.2175001502035 331.5 287.4999999999998 337.7824998497963 287.4999999999998 345.5 C287.4999999999998 353.2175001502037 281.2175001502035 359.5 273.4999999999998 359.5 Z "></path>\
                    	    </defs>\
                    	    <g style="mix-blend-mode:normal">\
                    	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_197-e98dc" fill="#114057" fill-opacity="1.0"></use>\
                    	    </g>\
                    	  </g>\
                    	</svg>\
\
                    </div>\
                  </div>\
                </div>\
                <div id="s-Button_2" class="button multiline manualfit firer commentable non-processed" customid="Quitar"   datasizewidth="71.0px" datasizeheight="23.0px" dataX="207.0" dataY="176.0" >\
                  <div class="backgroundLayer">\
                    <div class="colorLayer"></div>\
                    <div class="imageLayer"></div>\
                  </div>\
                  <div class="borderLayer">\
                    <div class="paddingLayer">\
                      <div class="content">\
                        <div class="valign">\
                          <span id="rtr-s-Button_2_0">Quitar</span>\
                        </div>\
                      </div>\
                    </div>\
                  </div>\
                </div>\
                <div id="s-Paragraph_3" class="richtext autofit firer ie-background commentable non-processed" customid="Venta"   datasizewidth="41.8px" datasizeheight="18.0px" dataX="13.0" dataY="179.5" >\
                  <div class="backgroundLayer">\
                    <div class="colorLayer"></div>\
                    <div class="imageLayer"></div>\
                  </div>\
                  <div class="borderLayer">\
                    <div class="paddingLayer">\
                      <div class="content">\
                        <div class="valign">\
                          <span id="rtr-s-Paragraph_3_0">Venta</span>\
                        </div>\
                      </div>\
                    </div>\
                  </div>\
                </div>\
                <div id="s-Paragraph_4" class="richtext autofit firer ie-background commentable non-processed" customid="20/01/2024"   datasizewidth="80.1px" datasizeheight="18.0px" dataX="14.8" dataY="114.0" >\
                  <div class="backgroundLayer">\
                    <div class="colorLayer"></div>\
                    <div class="imageLayer"></div>\
                  </div>\
                  <div class="borderLayer">\
                    <div class="paddingLayer">\
                      <div class="content">\
                        <div class="valign">\
                          <span id="rtr-s-Paragraph_4_0">20/01/2024</span>\
                        </div>\
                      </div>\
                    </div>\
                  </div>\
                </div>\
                <div id="s-Path_103" class="path firer commentable non-processed" customid="Email"   datasizewidth="20.0px" datasizeheight="16.0px" dataX="261.0" dataY="8.0"  >\
                  <div class="borderLayer">\
                  	<div class="imageViewport">\
                    	<?xml version="1.0" encoding="UTF-8"?>\
                    	<svg xmlns="http://www.w3.org/2000/svg" width="20.0" height="16.0" viewBox="260.9999999999998 7.999999999999972 20.0 16.0" preserveAspectRatio="none">\
                    	  <g>\
                    	    <defs>\
                    	      <path id="s-Path_103-e98dc" d="M278.9999999999998 7.999999999999972 L262.9999999999998 7.999999999999972 C261.8999999761579 7.999999999999972 261.00999999046303 8.899999976158114 261.00999999046303 9.999999999999972 L260.9999999999998 21.99999999999997 C260.9999999999998 23.10000002384183 261.8999999761579 23.99999999999997 262.9999999999998 23.99999999999997 L278.9999999999998 23.99999999999997 C280.10000002384163 23.99999999999997 280.9999999999998 23.10000002384183 280.9999999999998 21.99999999999997 L280.9999999999998 9.999999999999972 C280.9999999999998 8.899999976158114 280.10000002384163 7.999999999999972 278.9999999999998 7.999999999999972 Z M278.9999999999998 11.999999999999972 L270.9999999999998 16.99999999999997 L262.9999999999998 11.999999999999972 L262.9999999999998 9.999999999999972 L270.9999999999998 14.999999999999972 L278.9999999999998 9.999999999999972 L278.9999999999998 11.999999999999972 Z "></path>\
                    	    </defs>\
                    	    <g style="mix-blend-mode:normal">\
                    	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_103-e98dc" fill="#104057" fill-opacity="1.0"></use>\
                    	    </g>\
                    	  </g>\
                    	</svg>\
\
                    </div>\
                  </div>\
                </div>\
                <div id="s-Path_1" class="path firer commentable non-processed" customid="Email"   datasizewidth="20.0px" datasizeheight="16.0px" dataX="261.0" dataY="110.0"  >\
                  <div class="borderLayer">\
                  	<div class="imageViewport">\
                    	<?xml version="1.0" encoding="UTF-8"?>\
                    	<svg xmlns="http://www.w3.org/2000/svg" width="20.0" height="16.0" viewBox="260.9999999999998 109.99999999999997 20.0 16.0" preserveAspectRatio="none">\
                    	  <g>\
                    	    <defs>\
                    	      <path id="s-Path_1-e98dc" d="M278.9999999999998 109.99999999999997 L262.9999999999998 109.99999999999997 C261.8999999761579 109.99999999999997 261.00999999046303 110.89999997615811 261.00999999046303 111.99999999999997 L260.9999999999998 123.99999999999997 C260.9999999999998 125.10000002384183 261.8999999761579 125.99999999999997 262.9999999999998 125.99999999999997 L278.9999999999998 125.99999999999997 C280.10000002384163 125.99999999999997 280.9999999999998 125.10000002384183 280.9999999999998 123.99999999999997 L280.9999999999998 111.99999999999997 C280.9999999999998 110.89999997615811 280.10000002384163 109.99999999999997 278.9999999999998 109.99999999999997 Z M278.9999999999998 113.99999999999997 L270.9999999999998 118.99999999999997 L262.9999999999998 113.99999999999997 L262.9999999999998 111.99999999999997 L270.9999999999998 116.99999999999997 L278.9999999999998 111.99999999999997 L278.9999999999998 113.99999999999997 Z "></path>\
                    	    </defs>\
                    	    <g style="mix-blend-mode:normal">\
                    	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_1-e98dc" fill="#104057" fill-opacity="1.0"></use>\
                    	    </g>\
                    	  </g>\
                    	</svg>\
\
                    </div>\
                  </div>\
                </div>\
                </div>\
\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Panel_5" class="panel hidden firer ie-background commentable non-processed" customid="Panel 5"  datasizewidth="291.0px" datasizeheight="363.0px" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
          	<div class="layoutWrapper scrollable">\
          	  <div class="paddingLayer">\
                <div class="freeLayout">\
                <div id="s-Table_3" class="table firer commentable non-processed" customid="Table 1"  datasizewidth="291.0px" datasizeheight="274.0px" dataX="0.0" dataY="0.0" originalwidth="288.9999999999998px" originalheight="272.0px" >\
                  <div class="backgroundLayer">\
                    <div class="colorLayer"></div>\
                    <div class="imageLayer"></div>\
                  </div>\
                  <div class="borderLayer">\
                    <div class="paddingLayer">\
                      <table summary="">\
                        <tbody>\
                          <tr>\
                            <td id="s-Cell_5" customid="Cell 1" class="cellcontainer firer ie-background non-processed"    datasizewidth="291.0px" datasizeheight="138.0px" dataX="0.0" dataY="0.0" originalwidth="288.9999999999999px" originalheight="136.00000000000006px" >\
                              <div class="cellContainerChild">\
                                <div class="backgroundLayer">\
                                  <div class="colorLayer"></div>\
                                  <div class="imageLayer"></div>\
                                </div>\
                                <div class="borderLayer">\
                              	  <div class="layout scrollable">\
                              	    <div class="paddingLayer">\
                                      <table class="layout" summary="">\
                                        <tr>\
                                          <td class="layout vertical insertionpoint verticalalign Cell_5 Table_3" valign="middle" align="center" hSpacing="0" vSpacing="0"></td> \
                                        </tr>\
                                      </table>\
\
                                    </div>\
                                  </div>\
                                </div>\
                              </div>\
                            </td>\
                          </tr>\
                          <tr>\
                            <td id="s-Cell_6" customid="Cell 2" class="cellcontainer firer ie-background non-processed"    datasizewidth="291.0px" datasizeheight="138.0px" dataX="0.0" dataY="0.0" originalwidth="288.9999999999999px" originalheight="136.00000000000006px" >\
                              <div class="cellContainerChild">\
                                <div class="backgroundLayer">\
                                  <div class="colorLayer"></div>\
                                  <div class="imageLayer"></div>\
                                </div>\
                                <div class="borderLayer">\
                              	  <div class="layout scrollable">\
                              	    <div class="paddingLayer">\
                                      <table class="layout" summary="">\
                                        <tr>\
                                          <td class="layout vertical insertionpoint verticalalign Cell_6 Table_3" valign="middle" align="center" hSpacing="0" vSpacing="0"></td> \
                                        </tr>\
                                      </table>\
\
                                    </div>\
                                  </div>\
                                </div>\
                              </div>\
                            </td>\
                          </tr>\
                        </tbody>\
                      </table>\
                    </div>\
                  </div>\
                </div>\
                <div id="s-Paragraph_11" class="richtext manualfit firer ie-background commentable non-processed" customid="Intercambio de: Manuel Ji"   datasizewidth="141.4px" datasizeheight="36.0px" dataX="8.0" dataY="43.0" >\
                  <div class="backgroundLayer">\
                    <div class="colorLayer"></div>\
                    <div class="imageLayer"></div>\
                  </div>\
                  <div class="borderLayer">\
                    <div class="paddingLayer">\
                      <div class="content">\
                        <div class="valign">\
                          <span id="rtr-s-Paragraph_11_0">Intercambio de: </span><span id="rtr-s-Paragraph_11_1">Manuel Jimenez</span>\
                        </div>\
                      </div>\
                    </div>\
                  </div>\
                </div>\
                <div id="s-Paragraph_9" class="richtext autofit firer ie-background commentable non-processed" customid="18/01/2024"   datasizewidth="80.1px" datasizeheight="18.0px" dataX="8.0" dataY="9.0" >\
                  <div class="backgroundLayer">\
                    <div class="colorLayer"></div>\
                    <div class="imageLayer"></div>\
                  </div>\
                  <div class="borderLayer">\
                    <div class="paddingLayer">\
                      <div class="content">\
                        <div class="valign">\
                          <span id="rtr-s-Paragraph_9_0">18/01/2024</span>\
                        </div>\
                      </div>\
                    </div>\
                  </div>\
                </div>\
                <div id="s-Paragraph_10" class="richtext autofit firer ie-background commentable non-processed" customid="28/01/2024"   datasizewidth="80.1px" datasizeheight="18.0px" dataX="8.0" dataY="143.0" >\
                  <div class="backgroundLayer">\
                    <div class="colorLayer"></div>\
                    <div class="imageLayer"></div>\
                  </div>\
                  <div class="borderLayer">\
                    <div class="paddingLayer">\
                      <div class="content">\
                        <div class="valign">\
                          <span id="rtr-s-Paragraph_10_0">28/01/2024</span>\
                        </div>\
                      </div>\
                    </div>\
                  </div>\
                </div>\
                <div id="s-Paragraph_12" class="richtext autofit firer ie-background commentable non-processed" customid="Preferencias17/01/2024"   datasizewidth="89.8px" datasizeheight="36.0px" dataX="190.0" dataY="7.0" >\
                  <div class="backgroundLayer">\
                    <div class="colorLayer"></div>\
                    <div class="imageLayer"></div>\
                  </div>\
                  <div class="borderLayer">\
                    <div class="paddingLayer">\
                      <div class="content">\
                        <div class="valign">\
                          <span id="rtr-s-Paragraph_12_0">Preferencias<br />17/01/2024</span>\
                        </div>\
                      </div>\
                    </div>\
                  </div>\
                </div>\
                <div id="s-Paragraph_14" class="richtext manualfit firer ie-background commentable non-processed" customid="Venta de: Alberto L&oacute;pez"   datasizewidth="127.4px" datasizeheight="36.0px" dataX="8.3" dataY="166.0" >\
                  <div class="backgroundLayer">\
                    <div class="colorLayer"></div>\
                    <div class="imageLayer"></div>\
                  </div>\
                  <div class="borderLayer">\
                    <div class="paddingLayer">\
                      <div class="content">\
                        <div class="valign">\
                          <span id="rtr-s-Paragraph_14_0">Venta de:</span><span id="rtr-s-Paragraph_14_1"> Alberto L&oacute;pez</span>\
                        </div>\
                      </div>\
                    </div>\
                  </div>\
                </div>\
                <div id="s-Rectangle_2" class="rectangle manualfit firer commentable non-processed" customid="Rectangle 2"   datasizewidth="287.0px" datasizeheight="48.0px" datasizewidthpx="287.0" datasizeheightpx="48.0" dataX="1.0" dataY="87.0" >\
                  <div class="backgroundLayer">\
                    <div class="colorLayer"></div>\
                    <div class="imageLayer"></div>\
                  </div>\
                  <div class="borderLayer">\
                    <div class="paddingLayer">\
                      <div class="content">\
                        <div class="valign">\
                          <span id="rtr-s-Rectangle_2_0"></span>\
                        </div>\
                      </div>\
                    </div>\
                  </div>\
                </div>\
                <div id="s-Paragraph_13" class="richtext manualfit firer ie-background commentable non-processed" customid="Detalles: Tambi&eacute;n puedo c"   datasizewidth="267.7px" datasizeheight="36.0px" dataX="7.3" dataY="94.0" >\
                  <div class="backgroundLayer">\
                    <div class="colorLayer"></div>\
                    <div class="imageLayer"></div>\
                  </div>\
                  <div class="borderLayer">\
                    <div class="paddingLayer">\
                      <div class="content">\
                        <div class="valign">\
                          <span id="rtr-s-Paragraph_13_0">Detalles: </span><span id="rtr-s-Paragraph_13_1">Tambi&eacute;n puedo cambiar a partir del 25 de enero</span>\
                        </div>\
                      </div>\
                    </div>\
                  </div>\
                </div>\
                <div id="s-Rectangle_3" class="rectangle manualfit firer commentable non-processed" customid="Rectangle 2"   datasizewidth="287.0px" datasizeheight="48.0px" datasizewidthpx="287.0" datasizeheightpx="48.0" dataX="0.5" dataY="223.0" >\
                  <div class="backgroundLayer">\
                    <div class="colorLayer"></div>\
                    <div class="imageLayer"></div>\
                  </div>\
                  <div class="borderLayer">\
                    <div class="paddingLayer">\
                      <div class="content">\
                        <div class="valign">\
                          <span id="rtr-s-Rectangle_3_0"></span>\
                        </div>\
                      </div>\
                    </div>\
                  </div>\
                </div>\
                <div id="s-Paragraph_15" class="richtext manualfit firer ie-background commentable non-processed" customid="Detalles: Puedo realizar "   datasizewidth="267.7px" datasizeheight="36.0px" dataX="11.3" dataY="229.0" >\
                  <div class="backgroundLayer">\
                    <div class="colorLayer"></div>\
                    <div class="imageLayer"></div>\
                  </div>\
                  <div class="borderLayer">\
                    <div class="paddingLayer">\
                      <div class="content">\
                        <div class="valign">\
                          <span id="rtr-s-Paragraph_15_0">Detalles: </span><span id="rtr-s-Paragraph_15_1">Puedo realizar tambi&eacute;n intercambio</span>\
                        </div>\
                      </div>\
                    </div>\
                  </div>\
                </div>\
                </div>\
\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>  \
</div>\
';
document.getElementById("chromeTransfer").innerHTML = content;