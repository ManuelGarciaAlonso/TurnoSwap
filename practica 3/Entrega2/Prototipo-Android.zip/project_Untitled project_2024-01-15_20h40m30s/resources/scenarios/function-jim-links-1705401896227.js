(function(window, undefined) {

  var jimLinks = {
    "21e242de-c135-4170-a410-53f89a717b74" : {
      "Button_1" : [
        "9cb2ae55-5764-4724-bba4-cdcf0285a09d"
      ]
    },
    "9cb2ae55-5764-4724-bba4-cdcf0285a09d" : {
      "Button_2" : [
        "ffdd3acf-e061-4d1a-bcfe-92b8dc5a8a72"
      ],
      "Button_4" : [
        "85fe97aa-0758-420c-a300-619ad30a209f"
      ]
    },
    "f28727e6-514c-4f81-874f-6cfb1634b916" : {
      "Image_1" : [
        "be5d2066-45c8-4c1f-bb30-b43c785192a8"
      ],
      "Path_386" : [
        "39dde134-b706-4824-b17d-7511961dacdb"
      ],
      "Button_1" : [
        "e98dc6e4-1e98-4487-9027-5fda9eb217e7"
      ]
    },
    "daf5e08a-c288-4150-8f3a-6d3ab8f1e585" : {
      "Button_1" : [
        "21e242de-c135-4170-a410-53f89a717b74"
      ],
      "Paragraph_2" : [
        "4a47a490-84e4-450d-9160-f9831c729520"
      ]
    },
    "ffdd3acf-e061-4d1a-bcfe-92b8dc5a8a72" : {
      "Button_1" : [
        "a9c01755-8b88-4575-8b2b-53e7e62f0a5f"
      ]
    },
    "39dde134-b706-4824-b17d-7511961dacdb" : {
      "Image_1" : [
        "be5d2066-45c8-4c1f-bb30-b43c785192a8"
      ]
    },
    "c9704a13-6a54-4624-87ed-39e890093678" : {
      "Image_1" : [
        "be5d2066-45c8-4c1f-bb30-b43c785192a8"
      ],
      "Path_386" : [
        "39dde134-b706-4824-b17d-7511961dacdb"
      ],
      "Rectangle_9" : [
        "e98dc6e4-1e98-4487-9027-5fda9eb217e7"
      ],
      "Cell_5" : [
        "3e2760b7-7843-4bbc-9055-05a19f09d31f"
      ]
    },
    "85fe97aa-0758-420c-a300-619ad30a209f" : {
      "Button_1" : [
        "a9c01755-8b88-4575-8b2b-53e7e62f0a5f"
      ]
    },
    "0dbe17c5-21b8-4a25-b066-3b56d46c1c7b" : {
      "Image_1" : [
        "be5d2066-45c8-4c1f-bb30-b43c785192a8"
      ],
      "Path_386" : [
        "39dde134-b706-4824-b17d-7511961dacdb"
      ],
      "Button_2" : [
        "e98dc6e4-1e98-4487-9027-5fda9eb217e7"
      ],
      "Button_3" : [
        "3e2760b7-7843-4bbc-9055-05a19f09d31f"
      ]
    },
    "a9c01755-8b88-4575-8b2b-53e7e62f0a5f" : {
      "Button_1" : [
        "7ac1db64-5927-4aee-be9d-094ea8c22e17"
      ]
    },
    "6c1fa136-f932-4b94-a007-5666642ee9fc" : {
      "Image_1" : [
        "be5d2066-45c8-4c1f-bb30-b43c785192a8"
      ],
      "Image_2" : [
        "e98dc6e4-1e98-4487-9027-5fda9eb217e7"
      ],
      "Path_386" : [
        "39dde134-b706-4824-b17d-7511961dacdb"
      ],
      "Text_cell_6" : [
        "3e2760b7-7843-4bbc-9055-05a19f09d31f"
      ]
    },
    "e98dc6e4-1e98-4487-9027-5fda9eb217e7" : {
      "Image_1" : [
        "be5d2066-45c8-4c1f-bb30-b43c785192a8"
      ],
      "Path_386" : [
        "39dde134-b706-4824-b17d-7511961dacdb"
      ],
      "Rectangle_8" : [
        "c9704a13-6a54-4624-87ed-39e890093678"
      ],
      "Path_197" : [
        "f28727e6-514c-4f81-874f-6cfb1634b916"
      ]
    },
    "3e2760b7-7843-4bbc-9055-05a19f09d31f" : {
      "Image_1" : [
        "be5d2066-45c8-4c1f-bb30-b43c785192a8"
      ],
      "Path_386" : [
        "39dde134-b706-4824-b17d-7511961dacdb"
      ],
      "Button_1" : [
        "0dbe17c5-21b8-4a25-b066-3b56d46c1c7b"
      ]
    },
    "be5d2066-45c8-4c1f-bb30-b43c785192a8" : {
      "Image_2" : [
        "e98dc6e4-1e98-4487-9027-5fda9eb217e7"
      ],
      "Path_386" : [
        "39dde134-b706-4824-b17d-7511961dacdb"
      ],
      "Text_cell_218" : [
        "6c1fa136-f932-4b94-a007-5666642ee9fc"
      ]
    },
    "4a47a490-84e4-450d-9160-f9831c729520" : {
      "Button_1" : [
        "be5d2066-45c8-4c1f-bb30-b43c785192a8"
      ],
      "Paragraph_2" : [
        "daf5e08a-c288-4150-8f3a-6d3ab8f1e585"
      ]
    },
    "7ac1db64-5927-4aee-be9d-094ea8c22e17" : {
      "Button_1" : [
        "be5d2066-45c8-4c1f-bb30-b43c785192a8"
      ]
    },
    "d12245cc-1680-458d-89dd-4f0d7fb22724" : {
      "Button_1" : [
        "4a47a490-84e4-450d-9160-f9831c729520"
      ],
      "Button_2" : [
        "daf5e08a-c288-4150-8f3a-6d3ab8f1e585"
      ]
    }    
  }

  window.jimLinks = jimLinks;
})(window);