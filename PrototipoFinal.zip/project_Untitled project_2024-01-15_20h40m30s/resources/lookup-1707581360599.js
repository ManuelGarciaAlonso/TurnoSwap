(function(window, undefined) {
  var dictionary = {
    "21e242de-c135-4170-a410-53f89a717b74": "Empieza",
    "9cb2ae55-5764-4724-bba4-cdcf0285a09d": "grupo",
    "f28727e6-514c-4f81-874f-6cfb1634b916": "AniadirCambios",
    "daf5e08a-c288-4150-8f3a-6d3ab8f1e585": "Registro",
    "ffdd3acf-e061-4d1a-bcfe-92b8dc5a8a72": "CrearGrup",
    "39dde134-b706-4824-b17d-7511961dacdb": "perfil",
    "c9704a13-6a54-4624-87ed-39e890093678": "otrosCambios",
    "0dbe17c5-21b8-4a25-b066-3b56d46c1c7b": "cambioEsp2",
    "85fe97aa-0758-420c-a300-619ad30a209f": "IntroGrup",
    "3e2760b7-7843-4bbc-9055-05a19f09d31f": "cambioEsp",
    "6c1fa136-f932-4b94-a007-5666642ee9fc": "turnos",
    "a9c01755-8b88-4575-8b2b-53e7e62f0a5f": "CalendarioIni",
    "e98dc6e4-1e98-4487-9027-5fda9eb217e7": "cambios",
    "be5d2066-45c8-4c1f-bb30-b43c785192a8": "InicioDef",
    "4a47a490-84e4-450d-9160-f9831c729520": "IniSesion",
    "7ac1db64-5927-4aee-be9d-094ea8c22e17": "Completa",
    "d12245cc-1680-458d-89dd-4f0d7fb22724": "Inicio",
    "f39803f7-df02-4169-93eb-7547fb8c961a": "Template 1",
    "bb8abf58-f55e-472d-af05-a7d1bb0cc014": "default"
  };

  var uriRE = /^(\/#)?(screens|templates|masters|scenarios)\/(.*)(\.html)?/;
  window.lookUpURL = function(fragment) {
    var matches = uriRE.exec(fragment || "") || [],
        folder = matches[2] || "",
        canvas = matches[3] || "",
        name, url;
    if(dictionary.hasOwnProperty(canvas)) { /* search by name */
      url = folder + "/" + canvas;
    }
    return url;
  };

  window.lookUpName = function(fragment) {
    var matches = uriRE.exec(fragment || "") || [],
        folder = matches[2] || "",
        canvas = matches[3] || "",
        name, canvasName;
    if(dictionary.hasOwnProperty(canvas)) { /* search by name */
      canvasName = dictionary[canvas];
    }
    return canvasName;
  };
})(window);