	window.widgets = {
		descriptionMap : widgetDescriptionMap = {},
		rootWidgetMap : widgetRootMap = {}
	};

	widgets.descriptionMap[["s-Path_386", "f28727e6-514c-4f81-874f-6cfb1634b916"]] = ""; 

			widgets.rootWidgetMap[["s-Path_386", "f28727e6-514c-4f81-874f-6cfb1634b916"]] = ["User", "s-Path_386"]; 

	widgets.descriptionMap[["s-Path_1", "f28727e6-514c-4f81-874f-6cfb1634b916"]] = ""; 

			widgets.rootWidgetMap[["s-Path_1", "f28727e6-514c-4f81-874f-6cfb1634b916"]] = ["Arrow back", "s-Path_1"]; 

	widgets.descriptionMap[["s-Path_173", "ffdd3acf-e061-4d1a-bcfe-92b8dc5a8a72"]] = ""; 

			widgets.rootWidgetMap[["s-Path_173", "ffdd3acf-e061-4d1a-bcfe-92b8dc5a8a72"]] = ["Share", "s-Path_173"]; 

	widgets.descriptionMap[["s-Path_42", "39dde134-b706-4824-b17d-7511961dacdb"]] = ""; 

			widgets.rootWidgetMap[["s-Path_42", "39dde134-b706-4824-b17d-7511961dacdb"]] = ["Search", "s-Path_42"]; 

	widgets.descriptionMap[["s-Path_286", "39dde134-b706-4824-b17d-7511961dacdb"]] = ""; 

			widgets.rootWidgetMap[["s-Path_286", "39dde134-b706-4824-b17d-7511961dacdb"]] = ["Secure", "s-Path_286"]; 

	widgets.descriptionMap[["s-Path_176", "39dde134-b706-4824-b17d-7511961dacdb"]] = ""; 

			widgets.rootWidgetMap[["s-Path_176", "39dde134-b706-4824-b17d-7511961dacdb"]] = ["Alert", "s-Path_176"]; 

	widgets.descriptionMap[["s-Path_8", "39dde134-b706-4824-b17d-7511961dacdb"]] = ""; 

			widgets.rootWidgetMap[["s-Path_8", "39dde134-b706-4824-b17d-7511961dacdb"]] = ["Account circle", "s-Path_8"]; 

	widgets.descriptionMap[["s-Path_386", "39dde134-b706-4824-b17d-7511961dacdb"]] = ""; 

			widgets.rootWidgetMap[["s-Path_386", "39dde134-b706-4824-b17d-7511961dacdb"]] = ["User", "s-Path_386"]; 

	widgets.descriptionMap[["s-Path_386", "c9704a13-6a54-4624-87ed-39e890093678"]] = ""; 

			widgets.rootWidgetMap[["s-Path_386", "c9704a13-6a54-4624-87ed-39e890093678"]] = ["User", "s-Path_386"]; 

	widgets.descriptionMap[["s-Rectangle_6", "c9704a13-6a54-4624-87ed-39e890093678"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_6", "c9704a13-6a54-4624-87ed-39e890093678"]] = ["Tabs", "s-Dynamic_Panel_1"]; 

	widgets.descriptionMap[["s-Rectangle_8", "c9704a13-6a54-4624-87ed-39e890093678"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_8", "c9704a13-6a54-4624-87ed-39e890093678"]] = ["Tabs", "s-Dynamic_Panel_1"]; 

	widgets.descriptionMap[["s-Rectangle_9", "c9704a13-6a54-4624-87ed-39e890093678"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_9", "c9704a13-6a54-4624-87ed-39e890093678"]] = ["Tabs", "s-Dynamic_Panel_1"]; 

	widgets.descriptionMap[["s-Rectangle_10", "c9704a13-6a54-4624-87ed-39e890093678"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_10", "c9704a13-6a54-4624-87ed-39e890093678"]] = ["Tabs", "s-Dynamic_Panel_1"]; 

	widgets.descriptionMap[["s-Panel_1", "c9704a13-6a54-4624-87ed-39e890093678"]] = ""; 

			widgets.rootWidgetMap[["s-Panel_1", "c9704a13-6a54-4624-87ed-39e890093678"]] = ["Tabs", "s-Dynamic_Panel_1"]; 

	widgets.descriptionMap[["s-Path_1", "c9704a13-6a54-4624-87ed-39e890093678"]] = ""; 

			widgets.rootWidgetMap[["s-Path_1", "c9704a13-6a54-4624-87ed-39e890093678"]] = ["Search", "s-Path_1"]; 

	widgets.descriptionMap[["s-Path_2", "c9704a13-6a54-4624-87ed-39e890093678"]] = ""; 

			widgets.rootWidgetMap[["s-Path_2", "c9704a13-6a54-4624-87ed-39e890093678"]] = ["Filter list", "s-Path_2"]; 

	widgets.descriptionMap[["s-Path_386", "0dbe17c5-21b8-4a25-b066-3b56d46c1c7b"]] = ""; 

			widgets.rootWidgetMap[["s-Path_386", "0dbe17c5-21b8-4a25-b066-3b56d46c1c7b"]] = ["User", "s-Path_386"]; 

	widgets.descriptionMap[["s-Path_1", "0dbe17c5-21b8-4a25-b066-3b56d46c1c7b"]] = ""; 

			widgets.rootWidgetMap[["s-Path_1", "0dbe17c5-21b8-4a25-b066-3b56d46c1c7b"]] = ["Arrow back", "s-Path_1"]; 

	widgets.descriptionMap[["s-Path_171", "0dbe17c5-21b8-4a25-b066-3b56d46c1c7b"]] = ""; 

			widgets.rootWidgetMap[["s-Path_171", "0dbe17c5-21b8-4a25-b066-3b56d46c1c7b"]] = ["Send", "s-Path_171"]; 

	widgets.descriptionMap[["s-Path_386", "3e2760b7-7843-4bbc-9055-05a19f09d31f"]] = ""; 

			widgets.rootWidgetMap[["s-Path_386", "3e2760b7-7843-4bbc-9055-05a19f09d31f"]] = ["User", "s-Path_386"]; 

	widgets.descriptionMap[["s-Path_1", "3e2760b7-7843-4bbc-9055-05a19f09d31f"]] = ""; 

			widgets.rootWidgetMap[["s-Path_1", "3e2760b7-7843-4bbc-9055-05a19f09d31f"]] = ["Arrow back", "s-Path_1"]; 

	widgets.descriptionMap[["s-Path_171", "3e2760b7-7843-4bbc-9055-05a19f09d31f"]] = ""; 

			widgets.rootWidgetMap[["s-Path_171", "3e2760b7-7843-4bbc-9055-05a19f09d31f"]] = ["Send", "s-Path_171"]; 

	widgets.descriptionMap[["s-Path_386", "6c1fa136-f932-4b94-a007-5666642ee9fc"]] = ""; 

			widgets.rootWidgetMap[["s-Path_386", "6c1fa136-f932-4b94-a007-5666642ee9fc"]] = ["User", "s-Path_386"]; 

	widgets.descriptionMap[["s-Rectangle_6", "6c1fa136-f932-4b94-a007-5666642ee9fc"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_6", "6c1fa136-f932-4b94-a007-5666642ee9fc"]] = ["Tabs", "s-Dynamic_Panel_1"]; 

	widgets.descriptionMap[["s-Rectangle_7", "6c1fa136-f932-4b94-a007-5666642ee9fc"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_7", "6c1fa136-f932-4b94-a007-5666642ee9fc"]] = ["Tabs", "s-Dynamic_Panel_1"]; 

	widgets.descriptionMap[["s-Rectangle_8", "6c1fa136-f932-4b94-a007-5666642ee9fc"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_8", "6c1fa136-f932-4b94-a007-5666642ee9fc"]] = ["Tabs", "s-Dynamic_Panel_1"]; 

	widgets.descriptionMap[["s-Rectangle_9", "6c1fa136-f932-4b94-a007-5666642ee9fc"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_9", "6c1fa136-f932-4b94-a007-5666642ee9fc"]] = ["Tabs", "s-Dynamic_Panel_1"]; 

	widgets.descriptionMap[["s-Rectangle_10", "6c1fa136-f932-4b94-a007-5666642ee9fc"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_10", "6c1fa136-f932-4b94-a007-5666642ee9fc"]] = ["Tabs", "s-Dynamic_Panel_1"]; 

	widgets.descriptionMap[["s-Panel_1", "6c1fa136-f932-4b94-a007-5666642ee9fc"]] = ""; 

			widgets.rootWidgetMap[["s-Panel_1", "6c1fa136-f932-4b94-a007-5666642ee9fc"]] = ["Tabs", "s-Dynamic_Panel_1"]; 

	widgets.descriptionMap[["s-Path_117", "6c1fa136-f932-4b94-a007-5666642ee9fc"]] = ""; 

			widgets.rootWidgetMap[["s-Path_117", "6c1fa136-f932-4b94-a007-5666642ee9fc"]] = ["Arrow back", "s-Path_117"]; 

	widgets.descriptionMap[["s-Path_387", "6c1fa136-f932-4b94-a007-5666642ee9fc"]] = ""; 

			widgets.rootWidgetMap[["s-Path_387", "6c1fa136-f932-4b94-a007-5666642ee9fc"]] = ["User", "s-Path_387"]; 

	widgets.descriptionMap[["s-Path_1", "6c1fa136-f932-4b94-a007-5666642ee9fc"]] = ""; 

			widgets.rootWidgetMap[["s-Path_1", "6c1fa136-f932-4b94-a007-5666642ee9fc"]] = ["User", "s-Path_1"]; 

	widgets.descriptionMap[["s-Path_2", "6c1fa136-f932-4b94-a007-5666642ee9fc"]] = ""; 

			widgets.rootWidgetMap[["s-Path_2", "6c1fa136-f932-4b94-a007-5666642ee9fc"]] = ["User", "s-Path_2"]; 

	widgets.descriptionMap[["s-Path_3", "6c1fa136-f932-4b94-a007-5666642ee9fc"]] = ""; 

			widgets.rootWidgetMap[["s-Path_3", "6c1fa136-f932-4b94-a007-5666642ee9fc"]] = ["User", "s-Path_3"]; 

	widgets.descriptionMap[["s-Path_4", "6c1fa136-f932-4b94-a007-5666642ee9fc"]] = ""; 

			widgets.rootWidgetMap[["s-Path_4", "6c1fa136-f932-4b94-a007-5666642ee9fc"]] = ["User", "s-Path_4"]; 

	widgets.descriptionMap[["s-Path_5", "6c1fa136-f932-4b94-a007-5666642ee9fc"]] = ""; 

			widgets.rootWidgetMap[["s-Path_5", "6c1fa136-f932-4b94-a007-5666642ee9fc"]] = ["User", "s-Path_5"]; 

	widgets.descriptionMap[["s-Path_386", "e98dc6e4-1e98-4487-9027-5fda9eb217e7"]] = ""; 

			widgets.rootWidgetMap[["s-Path_386", "e98dc6e4-1e98-4487-9027-5fda9eb217e7"]] = ["User", "s-Path_386"]; 

	widgets.descriptionMap[["s-Rectangle_6", "e98dc6e4-1e98-4487-9027-5fda9eb217e7"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_6", "e98dc6e4-1e98-4487-9027-5fda9eb217e7"]] = ["Tabs", "s-Dynamic_Panel_1"]; 

	widgets.descriptionMap[["s-Rectangle_8", "e98dc6e4-1e98-4487-9027-5fda9eb217e7"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_8", "e98dc6e4-1e98-4487-9027-5fda9eb217e7"]] = ["Tabs", "s-Dynamic_Panel_1"]; 

	widgets.descriptionMap[["s-Rectangle_9", "e98dc6e4-1e98-4487-9027-5fda9eb217e7"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_9", "e98dc6e4-1e98-4487-9027-5fda9eb217e7"]] = ["Tabs", "s-Dynamic_Panel_1"]; 

	widgets.descriptionMap[["s-Rectangle_10", "e98dc6e4-1e98-4487-9027-5fda9eb217e7"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_10", "e98dc6e4-1e98-4487-9027-5fda9eb217e7"]] = ["Tabs", "s-Dynamic_Panel_1"]; 

	widgets.descriptionMap[["s-Panel_1", "e98dc6e4-1e98-4487-9027-5fda9eb217e7"]] = ""; 

			widgets.rootWidgetMap[["s-Panel_1", "e98dc6e4-1e98-4487-9027-5fda9eb217e7"]] = ["Tabs", "s-Dynamic_Panel_1"]; 

	widgets.descriptionMap[["s-Path_197", "e98dc6e4-1e98-4487-9027-5fda9eb217e7"]] = ""; 

			widgets.rootWidgetMap[["s-Path_197", "e98dc6e4-1e98-4487-9027-5fda9eb217e7"]] = ["Add circle outline", "s-Path_197"]; 

	widgets.descriptionMap[["s-Path_103", "e98dc6e4-1e98-4487-9027-5fda9eb217e7"]] = ""; 

			widgets.rootWidgetMap[["s-Path_103", "e98dc6e4-1e98-4487-9027-5fda9eb217e7"]] = ["Email", "s-Path_103"]; 

	widgets.descriptionMap[["s-Path_1", "e98dc6e4-1e98-4487-9027-5fda9eb217e7"]] = ""; 

			widgets.rootWidgetMap[["s-Path_1", "e98dc6e4-1e98-4487-9027-5fda9eb217e7"]] = ["Email", "s-Path_1"]; 

	widgets.descriptionMap[["s-Path_42", "e98dc6e4-1e98-4487-9027-5fda9eb217e7"]] = ""; 

			widgets.rootWidgetMap[["s-Path_42", "e98dc6e4-1e98-4487-9027-5fda9eb217e7"]] = ["Search", "s-Path_42"]; 

	widgets.descriptionMap[["s-Path_110", "e98dc6e4-1e98-4487-9027-5fda9eb217e7"]] = ""; 

			widgets.rootWidgetMap[["s-Path_110", "e98dc6e4-1e98-4487-9027-5fda9eb217e7"]] = ["Filter list", "s-Path_110"]; 

	widgets.descriptionMap[["s-Path_386", "be5d2066-45c8-4c1f-bb30-b43c785192a8"]] = ""; 

			widgets.rootWidgetMap[["s-Path_386", "be5d2066-45c8-4c1f-bb30-b43c785192a8"]] = ["User", "s-Path_386"]; 

	widgets.descriptionMap[["s-Rectangle_2", "be5d2066-45c8-4c1f-bb30-b43c785192a8"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_2", "be5d2066-45c8-4c1f-bb30-b43c785192a8"]] = ["Tabs", "s-Dynamic_Panel_1"]; 

	widgets.descriptionMap[["s-Rectangle_3", "be5d2066-45c8-4c1f-bb30-b43c785192a8"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_3", "be5d2066-45c8-4c1f-bb30-b43c785192a8"]] = ["Tabs", "s-Dynamic_Panel_1"]; 

	widgets.descriptionMap[["s-Rectangle_4", "be5d2066-45c8-4c1f-bb30-b43c785192a8"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_4", "be5d2066-45c8-4c1f-bb30-b43c785192a8"]] = ["Tabs", "s-Dynamic_Panel_1"]; 

	widgets.descriptionMap[["s-Rectangle_5", "be5d2066-45c8-4c1f-bb30-b43c785192a8"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_5", "be5d2066-45c8-4c1f-bb30-b43c785192a8"]] = ["Tabs", "s-Dynamic_Panel_1"]; 

	widgets.descriptionMap[["s-Rectangle_77", "be5d2066-45c8-4c1f-bb30-b43c785192a8"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_77", "be5d2066-45c8-4c1f-bb30-b43c785192a8"]] = ["Tabs", "s-Dynamic_Panel_1"]; 

	widgets.descriptionMap[["s-Panel_1", "be5d2066-45c8-4c1f-bb30-b43c785192a8"]] = ""; 

			widgets.rootWidgetMap[["s-Panel_1", "be5d2066-45c8-4c1f-bb30-b43c785192a8"]] = ["Tabs", "s-Dynamic_Panel_1"]; 

	widgets.descriptionMap[["s-Image", "7ac1db64-5927-4aee-be9d-094ea8c22e17"]] = ""; 

			widgets.rootWidgetMap[["s-Image", "7ac1db64-5927-4aee-be9d-094ea8c22e17"]] = ["Image", "s-Image"]; 

	