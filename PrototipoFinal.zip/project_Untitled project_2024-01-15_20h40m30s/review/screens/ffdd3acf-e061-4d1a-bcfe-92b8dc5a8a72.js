var content='<div class="ui-page" deviceName="androidphone" deviceType="mobile" deviceWidth="360" deviceHeight="640">\
    <div id="t-f39803f7-df02-4169-93eb-7547fb8c961a" class="template growth-both devMobile devAndroid android-device canvas firer commentable non-processed" alignment="left" name="Template 1" width="360" height="640">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1707581360599.css" />\
      <div class="freeLayout">\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>\
    <div id="s-ffdd3acf-e061-4d1a-bcfe-92b8dc5a8a72" class="screen growth-vertical devMobile devAndroid android-device canvas PORTRAIT firer ie-background commentable non-processed" alignment="left" name="CrearGrup" width="360" height="640">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/screens/ffdd3acf-e061-4d1a-bcfe-92b8dc5a8a72-1707581360599.css" />\
      <div class="freeLayout">\
      <div id="s-Button_1" class="button multiline manualfit firer click commentable non-processed" customid="Siguiente"   datasizewidth="94.0px" datasizeheight="45.0px" dataX="234.0" dataY="579.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Button_1_0">Siguiente</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Input_2" class="text firer commentable non-processed" customid="Input 1"  datasizewidth="300.0px" datasizeheight="45.0px" dataX="29.0" dataY="261.5" ><div class="backgroundLayer">\
        <div class="colorLayer"></div>\
        <div class="imageLayer"></div>\
      </div><div class="borderLayer"><div class="paddingLayer"><div class="content"><div class="valign"><input type="text"  value="" maxlength="100"  tabindex="-1" placeholder="Nombre de plantilla"/></div></div>  </div></div></div>\
      <div id="s-Paragraph_1" class="richtext manualfit firer ie-background commentable non-processed" customid="C&oacute;digo de plantilla: ABCD"   datasizewidth="248.6px" datasizeheight="29.0px" dataX="29.0" dataY="210.5" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_1_0">C&oacute;digo de plantilla: ABCD</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Path_173" class="path firer commentable non-processed" customid="Share"   datasizewidth="18.0px" datasizeheight="19.9px" dataX="311.0" dataY="324.0"  >\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg xmlns="http://www.w3.org/2000/svg" width="18.0" height="19.920000076293945" viewBox="310.99999999999994 324.00000005960464 18.0 19.920000076293945" preserveAspectRatio="none">\
          	  <g>\
          	    <defs>\
          	      <path id="s-Path_173-ffdd3" d="M325.99999999999994 338.0800002217293 C325.2400000095367 338.0800002217293 324.5599999427795 338.3800002336502 324.03999996185297 338.8500002026558 L316.90999984741205 334.70000010728836 C316.9599998481571 334.47000010311604 316.99999985098833 334.2400000989437 316.99999985098833 334.0000001192093 C316.99999985098833 333.76000013947487 316.9599998518824 333.5300001204014 316.90999984741205 333.3000001311302 L323.9600000381469 329.1899999976158 C324.5000000596046 329.6899999976158 325.2100000381469 330.0 325.99999999999994 330.0 C327.65999996662134 330.0 328.99999999999994 328.6599999666214 328.99999999999994 327.0 C328.99999999999994 325.3400000333786 327.65999996662134 324.0 325.99999999999994 324.0 C324.34000003337854 324.0 322.99999999999994 325.3400000333786 322.99999999999994 327.0 C322.99999999999994 327.2399999946356 323.0399999991059 327.4699999988079 323.0900000035762 327.69999998807907 L316.03999996185297 331.8100007176399 C315.49999999999994 331.3100007176399 314.78999996185297 331.0000002980232 313.99999999999994 331.0000002980232 C312.34000003337854 331.0000002980232 310.99999999999994 332.3400003314018 310.99999999999994 334.0000002980232 C310.99999999999994 335.6600002646446 312.34000003337854 337.0000002980232 313.99999999999994 337.0000002980232 C314.7900000214576 337.0000002980232 315.49999999999994 336.69000029563904 316.03999996185297 336.19000029563904 L323.15999984741205 340.35000014305115 C323.109999846667 340.56000013649464 323.0799998492002 340.7800001502037 323.0799998492002 341.0000001192093 C323.0799998492002 342.6100001335144 324.38999979197973 343.92000019550323 325.99999992549414 343.92000019550323 C327.60999993979925 343.92000019550323 328.9200000017881 342.6100002527237 328.9200000017881 341.0000001192093 C328.9200000017881 339.3899999856949 327.61000005900854 338.08000004291534 325.99999992549414 338.08000004291534 Z "></path>\
          	    </defs>\
          	    <g style="mix-blend-mode:normal">\
          	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_173-ffdd3" fill="#104057" fill-opacity="1.0"></use>\
          	    </g>\
          	  </g>\
          	</svg>\
\
          </div>\
        </div>\
      </div>\
      <div id="s-Button_2" class="button multiline manualfit firer click commentable non-processed" customid="Anterior"   datasizewidth="94.0px" datasizeheight="45.0px" dataX="30.0" dataY="579.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Button_2_0">Anterior</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>  \
</div>\
';
document.getElementById("chromeTransfer").innerHTML = content;