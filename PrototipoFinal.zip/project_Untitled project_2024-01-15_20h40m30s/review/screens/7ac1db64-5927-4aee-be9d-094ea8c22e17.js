var content='<div class="ui-page" deviceName="androidphone" deviceType="mobile" deviceWidth="360" deviceHeight="640">\
    <div id="t-f39803f7-df02-4169-93eb-7547fb8c961a" class="template growth-both devMobile devAndroid android-device canvas firer commentable non-processed" alignment="left" name="Template 1" width="360" height="640">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1707581360599.css" />\
      <div class="freeLayout">\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>\
    <div id="s-7ac1db64-5927-4aee-be9d-094ea8c22e17" class="screen growth-vertical devMobile devAndroid android-device canvas PORTRAIT firer ie-background commentable non-processed" alignment="left" name="Completa" width="360" height="640">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/screens/7ac1db64-5927-4aee-be9d-094ea8c22e17-1707581360599.css" />\
      <div class="freeLayout">\
      <div id="s-Button_1" class="button multiline manualfit firer click commentable non-processed" customid="Siguiente"   datasizewidth="94.0px" datasizeheight="45.0px" dataX="244.0" dataY="579.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Button_1_0">Siguiente</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Input_1" class="text firer commentable non-processed" customid="Input 1"  datasizewidth="195.0px" datasizeheight="45.0px" dataX="135.0" dataY="130.0" ><div class="backgroundLayer">\
        <div class="colorLayer"></div>\
        <div class="imageLayer"></div>\
      </div><div class="borderLayer"><div class="paddingLayer"><div class="content"><div class="valign"><input type="text"  value="" maxlength="100"  tabindex="-1" placeholder="Nombre"/></div></div>  </div></div></div>\
      <div id="s-Input_2" class="text firer commentable non-processed" customid="Input 2"  datasizewidth="195.0px" datasizeheight="45.0px" dataX="135.0" dataY="205.0" ><div class="backgroundLayer">\
        <div class="colorLayer"></div>\
        <div class="imageLayer"></div>\
      </div><div class="borderLayer"><div class="paddingLayer"><div class="content"><div class="valign"><input type="text"  value="" maxlength="100"  tabindex="-1" placeholder="Apellidos"/></div></div>  </div></div></div>\
      <div id="s-Input_3" class="text firer commentable non-processed" customid="Input 1"  datasizewidth="300.0px" datasizeheight="45.0px" dataX="30.0" dataY="274.0" ><div class="backgroundLayer">\
        <div class="colorLayer"></div>\
        <div class="imageLayer"></div>\
      </div><div class="borderLayer"><div class="paddingLayer"><div class="content"><div class="valign"><input type="text"  value="" maxlength="100"  tabindex="-1" placeholder="Direcci&oacute;n"/></div></div>  </div></div></div>\
      <div id="s-Input_4" class="text firer commentable non-processed" customid="Input 2"  datasizewidth="300.0px" datasizeheight="45.0px" dataX="30.0" dataY="349.0" ><div class="backgroundLayer">\
        <div class="colorLayer"></div>\
        <div class="imageLayer"></div>\
      </div><div class="borderLayer"><div class="paddingLayer"><div class="content"><div class="valign"><input type="text"  value="" maxlength="100"  tabindex="-1" placeholder="Descripci&oacute;n"/></div></div>  </div></div></div>\
\
      <div id="s-Image" class="image firer ie-background commentable non-processed" customid="Image"   datasizewidth="88.0px" datasizeheight="120.0px" dataX="30.0" dataY="130.0"   alt="image">\
        <div class="borderLayer">\
        	<div class="imageViewport">\
        		<img src="resources/jim/images/common/cross.svg" />\
        	</div>\
        </div>\
      </div>\
\
      <div id="s-Paragraph_1" class="richtext autofit firer ie-background commentable non-processed" customid="Completa tu perfil"   datasizewidth="156.7px" datasizeheight="22.0px" dataX="39.6" dataY="74.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_1_0">Completa tu perfil</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Button_2" class="button multiline manualfit firer click commentable non-processed" customid="Anterior"   datasizewidth="94.0px" datasizeheight="45.0px" dataX="30.0" dataY="579.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Button_2_0">Anterior</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>  \
</div>\
';
document.getElementById("chromeTransfer").innerHTML = content;