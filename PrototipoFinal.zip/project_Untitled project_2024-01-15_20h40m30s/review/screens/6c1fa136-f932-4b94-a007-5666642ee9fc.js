var content='<div class="ui-page" deviceName="androidphone" deviceType="mobile" deviceWidth="360" deviceHeight="640">\
    <div id="t-f39803f7-df02-4169-93eb-7547fb8c961a" class="template growth-both devMobile devAndroid android-device canvas firer commentable non-processed" alignment="left" name="Template 1" width="360" height="640">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1707581360599.css" />\
      <div class="freeLayout">\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>\
    <div id="s-6c1fa136-f932-4b94-a007-5666642ee9fc" class="screen growth-vertical devMobile devAndroid android-device canvas PORTRAIT firer ie-background commentable non-processed" alignment="left" name="turnos" width="360" height="640">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/screens/6c1fa136-f932-4b94-a007-5666642ee9fc-1707581360599.css" />\
      <div class="freeLayout">\
      <div id="s-Group_1" class="group firer ie-background commentable non-processed" customid="Group 1" datasizewidth="0.0px" datasizeheight="0.0px" >\
        <div id="s-Rectangle_1" class="rectangle manualfit firer commentable non-processed" customid="Rectangle 1"   datasizewidth="363.0px" datasizeheight="47.0px" datasizewidthpx="363.0000000432957" datasizeheightpx="47.0" dataX="-1.0" dataY="594.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Rectangle_1_0"></span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
\
        <div id="s-Image_1" class="image firer click ie-background commentable non-processed" customid="Image 1"   datasizewidth="50.4px" datasizeheight="47.0px" dataX="42.4" dataY="593.5"   alt="image">\
          <div class="borderLayer">\
          	<div class="imageViewport">\
          		<img src="./images/86da06ee-e2b7-435b-a167-c84b824d6989.png" />\
          	</div>\
          </div>\
        </div>\
\
\
        <div id="s-Image_2" class="image firer click ie-background commentable non-processed" customid="Image 2"   datasizewidth="34.3px" datasizeheight="29.0px" dataX="163.4" dataY="603.0"   alt="image">\
          <div class="borderLayer">\
          	<div class="imageViewport">\
          		<img src="./images/20814eda-f2b3-40bf-9c8f-5146b39bd9ce.png" />\
          	</div>\
          </div>\
        </div>\
\
        <div id="s-Path_386" class="path firer click commentable non-processed" customid="User"   datasizewidth="31.3px" datasizeheight="26.0px" dataX="280.3" dataY="604.0"  >\
          <div class="borderLayer">\
          	<div class="imageViewport">\
            	<?xml version="1.0" encoding="UTF-8"?>\
            	<svg xmlns="http://www.w3.org/2000/svg" width="31.25833511352539" height="26.0" viewBox="280.32500002660186 603.9999999999999 31.25833511352539 26.0" preserveAspectRatio="none">\
            	  <g>\
            	    <defs>\
            	      <path id="s-Path_386-6c1fa" d="M295.9541666951326 616.9999999999999 C300.2717240618399 616.9999999999999 303.76875002939795 614.0912500619887 303.76875002939795 610.4999999999999 C303.76875002939795 606.908749938011 300.2717240618399 603.9999999999999 295.9541666951326 603.9999999999999 C291.6366093284253 603.9999999999999 288.1395833608672 606.908749938011 288.1395833608672 610.4999999999999 C288.1395833608672 614.0912500619887 291.6366093284253 616.9999999999999 295.9541666951326 616.9999999999999 Z M295.9541666951326 620.2499999999999 C290.7379321704591 620.2499999999999 280.32500002660186 622.4275000542401 280.32500002660186 626.7499999999999 L280.32500002660186 629.9999999999999 L311.5833333636633 629.9999999999999 L311.5833333636633 626.7499999999999 C311.5833333636633 622.427499860525 301.1704012198061 620.2499999999999 295.9541666951326 620.2499999999999 Z "></path>\
            	    </defs>\
            	    <g style="mix-blend-mode:normal">\
            	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_386-6c1fa" fill="#000000" fill-opacity="1.0"></use>\
            	    </g>\
            	  </g>\
            	</svg>\
\
            </div>\
          </div>\
        </div>\
      </div>\
\
\
      <div id="s-Image_3" class="image firer ie-background commentable non-processed" customid="logo - copia"   datasizewidth="35.0px" datasizeheight="50.0px" dataX="162.5" dataY="9.0"   alt="image">\
        <div class="borderLayer">\
        	<div class="imageViewport">\
        		<img src="./images/4923cd6b-837d-4014-b812-bd711b348f73.png" />\
        	</div>\
        </div>\
      </div>\
\
      <div id="s-Dynamic_Panel_1" class="dynamicpanel firer ie-background commentable non-processed" customid="Primary tabs text" datasizewidth="360.0px" datasizeheight="51.0px" dataX="0.0" dataY="114.0" >\
        <div id="s-Panel_1" class="panel default firer ie-background commentable non-processed" customid="Panel"  datasizewidth="360.0px" datasizeheight="51.0px" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
          	<div class="layoutWrapper scrollable">\
          	  <div class="paddingLayer">\
                <div class="freeLayout">\
                <div id="s-Rectangle_6" class="rectangle manualfit firer commentable non-processed" customid="BG"   datasizewidth="360.0px" datasizeheight="47.5px" datasizewidthpx="360.0" datasizeheightpx="47.5" dataX="0.0" dataY="1.0" >\
                  <div class="backgroundLayer">\
                    <div class="colorLayer"></div>\
                    <div class="imageLayer"></div>\
                  </div>\
                  <div class="borderLayer">\
                    <div class="paddingLayer">\
                      <div class="content">\
                        <div class="valign">\
                          <span id="rtr-s-Rectangle_6_0"></span>\
                        </div>\
                      </div>\
                    </div>\
                  </div>\
                </div>\
                <div id="s-Rectangle_7" class="rectangle manualfit firer commentable non-processed" customid="Tab 3"   datasizewidth="120.0px" datasizeheight="34.0px" datasizewidthpx="120.00000000000023" datasizeheightpx="34.0" dataX="240.0" dataY="6.0" >\
                  <div class="backgroundLayer">\
                    <div class="colorLayer"></div>\
                    <div class="imageLayer"></div>\
                  </div>\
                  <div class="borderLayer">\
                    <div class="paddingLayer">\
                      <div class="content">\
                        <div class="valign">\
                          <span id="rtr-s-Rectangle_7_0">Noche</span>\
                        </div>\
                      </div>\
                    </div>\
                  </div>\
                </div>\
                <div id="s-Rectangle_8" class="rectangle manualfit firer commentable non-processed" customid="Tab 2"   datasizewidth="120.0px" datasizeheight="35.0px" datasizewidthpx="119.99999999999986" datasizeheightpx="35.0" dataX="120.0" dataY="6.0" >\
                  <div class="backgroundLayer">\
                    <div class="colorLayer"></div>\
                    <div class="imageLayer"></div>\
                  </div>\
                  <div class="borderLayer">\
                    <div class="paddingLayer">\
                      <div class="content">\
                        <div class="valign">\
                          <span id="rtr-s-Rectangle_8_0">Tarde</span>\
                        </div>\
                      </div>\
                    </div>\
                  </div>\
                </div>\
                <div id="s-Rectangle_9" class="rectangle manualfit firer ie-background commentable non-processed" customid="Tab 1"   datasizewidth="120.0px" datasizeheight="35.0px" datasizewidthpx="120.0" datasizeheightpx="35.0" dataX="0.4" dataY="6.0" >\
                  <div class="backgroundLayer">\
                    <div class="colorLayer"></div>\
                    <div class="imageLayer"></div>\
                  </div>\
                  <div class="borderLayer">\
                    <div class="paddingLayer">\
                      <div class="content">\
                        <div class="valign">\
                          <span id="rtr-s-Rectangle_9_0">Ma&ntilde;ana</span>\
                        </div>\
                      </div>\
                    </div>\
                  </div>\
                </div>\
                <div id="s-Rectangle_10" class="rectangle manualfit firer commentable non-processed" customid="Select tab"   datasizewidth="45.0px" datasizeheight="3.0px" datasizewidthpx="45.0" datasizeheightpx="3.0" dataX="37.9" dataY="46.0" >\
                  <div class="backgroundLayer">\
                    <div class="colorLayer"></div>\
                    <div class="imageLayer"></div>\
                  </div>\
                  <div class="borderLayer">\
                    <div class="paddingLayer">\
                      <div class="content">\
                        <div class="valign">\
                          <span id="rtr-s-Rectangle_10_0"></span>\
                        </div>\
                      </div>\
                    </div>\
                  </div>\
                </div>\
                </div>\
\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
\
      <div id="s-Group_2" class="group firer ie-background commentable non-processed" customid="Group 2" datasizewidth="0.0px" datasizeheight="0.0px" >\
        <div id="s-Rectangle_2" class="rectangle manualfit firer commentable non-processed" customid="Rectangle 2"   datasizewidth="360.0px" datasizeheight="35.0px" datasizewidthpx="360.0" datasizeheightpx="35.0" dataX="0.0" dataY="79.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Rectangle_2_0">1 de enero</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Path_117" class="path firer click commentable non-processed" customid="Arrow Back"   datasizewidth="20.0px" datasizeheight="20.0px" dataX="12.0" dataY="86.5"  >\
          <div class="borderLayer">\
          	<div class="imageViewport">\
            	<?xml version="1.0" encoding="UTF-8"?>\
            	<svg xmlns="http://www.w3.org/2000/svg" width="20.0" height="20.0" viewBox="12.0 86.50000000000013 20.0 20.0" preserveAspectRatio="none">\
            	  <g>\
            	    <defs>\
            	      <path id="s-Path_117-6c1fa" d="M32.0 95.25000000000013 L16.78749990463257 95.25000000000013 L23.77500009536743 88.26249980926526 L22.0 86.50000000000013 L12.0 96.50000000000013 L22.0 106.50000000000013 L23.76249995827675 104.73750004172338 L16.78749990463257 97.75000000000013 L32.0 97.75000000000013 L32.0 95.25000000000013 Z "></path>\
            	    </defs>\
            	    <g style="mix-blend-mode:normal">\
            	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_117-6c1fa" fill="#FFFFFF" fill-opacity="1.0"></use>\
            	    </g>\
            	  </g>\
            	</svg>\
\
            </div>\
          </div>\
        </div>\
      </div>\
\
      <div id="s-Table_1" class="table firer commentable non-processed" customid="Table 1"  datasizewidth="291.7px" datasizeheight="159.7px" dataX="34.2" dataY="217.0" originalwidth="289.6666666666664px" originalheight="157.66666666666654px" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <table summary="">\
              <tbody>\
                <tr>\
                  <td id="s-Text_cell_5" class="textcell manualfit firer ie-background non-processed" customid="Alberto L&oacute;pez"     datasizewidth="291.7px" datasizeheight="41.4px" dataX="0.0" dataY="0.0" originalwidth="289.66666666666646px" originalheight="39.41666666666662px" ><div class="cellContainerChild"><div class="backgroundLayer">\
                    <div class="colorLayer"></div>\
                    <div class="imageLayer"></div>\
                  </div><div class="borderLayer"><div class="paddingLayer"><div class="clipping"><div class="content"><div class="valign"><span id="rtr-s-Text_cell_5_0">Alberto L&oacute;pez</span></div></div></div></div></div></div>  </td>\
                </tr>\
                <tr>\
                  <td id="s-Text_cell_6" class="textcell manualfit firer ie-background non-processed" customid="Manuel Jimenez"     datasizewidth="291.7px" datasizeheight="41.4px" dataX="0.0" dataY="0.0" originalwidth="289.66666666666646px" originalheight="39.41666666666662px" ><div class="cellContainerChild"><div class="backgroundLayer">\
                    <div class="colorLayer"></div>\
                    <div class="imageLayer"></div>\
                  </div><div class="borderLayer"><div class="paddingLayer"><div class="clipping"><div class="content"><div class="valign"><span id="rtr-s-Text_cell_6_0">Manuel Jimenez</span></div></div></div></div></div></div>  </td>\
                </tr>\
                <tr>\
                  <td id="s-Text_cell_7" class="textcell manualfit firer ie-background non-processed" customid="Ana Vico"     datasizewidth="291.7px" datasizeheight="41.4px" dataX="0.0" dataY="0.0" originalwidth="289.6666666666665px" originalheight="39.41666666666662px" ><div class="cellContainerChild"><div class="backgroundLayer">\
                    <div class="colorLayer"></div>\
                    <div class="imageLayer"></div>\
                  </div><div class="borderLayer"><div class="paddingLayer"><div class="clipping"><div class="content"><div class="valign"><span id="rtr-s-Text_cell_7_0">Ana Vico</span></div></div></div></div></div></div>  </td>\
                </tr>\
                <tr>\
                  <td id="s-Text_cell_8" class="textcell manualfit firer ie-background non-processed" customid="Antonio Banderas"     datasizewidth="291.7px" datasizeheight="41.4px" dataX="0.0" dataY="0.0" originalwidth="289.66666666666646px" originalheight="39.41666666666662px" ><div class="cellContainerChild"><div class="backgroundLayer">\
                    <div class="colorLayer"></div>\
                    <div class="imageLayer"></div>\
                  </div><div class="borderLayer"><div class="paddingLayer"><div class="clipping"><div class="content"><div class="valign"><span id="rtr-s-Text_cell_8_0">Antonio Banderas</span></div></div></div></div></div></div>  </td>\
                </tr>\
              </tbody>\
            </table>\
          </div>\
        </div>\
      </div>\
      <div id="s-Paragraph_1" class="richtext autofit firer ie-background commentable non-processed" customid="Personas en el turno:"   datasizewidth="152.1px" datasizeheight="18.0px" dataX="32.0" dataY="183.6" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_1_0">Personas en el turno:</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Path_387" class="path firer commentable non-processed" customid="User"   datasizewidth="16.0px" datasizeheight="16.0px" dataX="47.0" dataY="229.0"  >\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg xmlns="http://www.w3.org/2000/svg" width="16.0" height="16.0" viewBox="47.0 229.0 16.0 16.0" preserveAspectRatio="none">\
          	  <g>\
          	    <defs>\
          	      <path id="s-Path_387-6c1fa" d="M55.0 237.0 C57.21000003814697 237.0 59.0 235.21000003814697 59.0 233.0 C59.0 230.78999996185303 57.21000003814697 229.0 55.0 229.0 C52.78999996185303 229.0 51.0 230.78999996185303 51.0 233.0 C51.0 235.21000003814697 52.78999996185303 237.0 55.0 237.0 Z M55.0 239.0 C52.329999923706055 239.0 47.0 240.3400000333786 47.0 243.0 L47.0 245.0 L63.0 245.0 L63.0 243.0 C63.0 240.3399999141693 57.670000076293945 239.0 55.0 239.0 Z "></path>\
          	    </defs>\
          	    <g style="mix-blend-mode:normal">\
          	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_387-6c1fa" fill="#104059" fill-opacity="1.0"></use>\
          	    </g>\
          	  </g>\
          	</svg>\
\
          </div>\
        </div>\
      </div>\
      <div id="s-Path_1" class="path firer commentable non-processed" customid="User"   datasizewidth="16.0px" datasizeheight="16.0px" dataX="47.0" dataY="269.0"  >\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg xmlns="http://www.w3.org/2000/svg" width="16.0" height="16.0" viewBox="47.000000000000014 269.0 16.0 16.0" preserveAspectRatio="none">\
          	  <g>\
          	    <defs>\
          	      <path id="s-Path_1-6c1fa" d="M55.000000000000014 277.0 C57.21000003814699 277.0 59.000000000000014 275.210000038147 59.000000000000014 273.0 C59.000000000000014 270.789999961853 57.21000003814699 269.0 55.000000000000014 269.0 C52.78999996185304 269.0 51.000000000000014 270.789999961853 51.000000000000014 273.0 C51.000000000000014 275.210000038147 52.78999996185304 277.0 55.000000000000014 277.0 Z M55.000000000000014 279.0 C52.32999992370607 279.0 47.000000000000014 280.3400000333786 47.000000000000014 283.0 L47.000000000000014 285.0 L63.000000000000014 285.0 L63.000000000000014 283.0 C63.000000000000014 280.3399999141693 57.67000007629396 279.0 55.000000000000014 279.0 Z "></path>\
          	    </defs>\
          	    <g style="mix-blend-mode:normal">\
          	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_1-6c1fa" fill="#104059" fill-opacity="1.0"></use>\
          	    </g>\
          	  </g>\
          	</svg>\
\
          </div>\
        </div>\
      </div>\
      <div id="s-Path_2" class="path firer commentable non-processed" customid="User"   datasizewidth="16.0px" datasizeheight="16.0px" dataX="47.0" dataY="308.0"  >\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg xmlns="http://www.w3.org/2000/svg" width="16.0" height="16.0" viewBox="47.000000000000014 308.0 16.0 16.0" preserveAspectRatio="none">\
          	  <g>\
          	    <defs>\
          	      <path id="s-Path_2-6c1fa" d="M55.000000000000014 316.0 C57.21000003814699 316.0 59.000000000000014 314.210000038147 59.000000000000014 312.0 C59.000000000000014 309.789999961853 57.21000003814699 308.0 55.000000000000014 308.0 C52.78999996185304 308.0 51.000000000000014 309.789999961853 51.000000000000014 312.0 C51.000000000000014 314.210000038147 52.78999996185304 316.0 55.000000000000014 316.0 Z M55.000000000000014 318.0 C52.32999992370607 318.0 47.000000000000014 319.3400000333786 47.000000000000014 322.0 L47.000000000000014 324.0 L63.000000000000014 324.0 L63.000000000000014 322.0 C63.000000000000014 319.3399999141693 57.67000007629396 318.0 55.000000000000014 318.0 Z "></path>\
          	    </defs>\
          	    <g style="mix-blend-mode:normal">\
          	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_2-6c1fa" fill="#104059" fill-opacity="1.0"></use>\
          	    </g>\
          	  </g>\
          	</svg>\
\
          </div>\
        </div>\
      </div>\
      <div id="s-Path_3" class="path firer commentable non-processed" customid="User"   datasizewidth="16.0px" datasizeheight="16.0px" dataX="47.0" dataY="348.0"  >\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg xmlns="http://www.w3.org/2000/svg" width="16.0" height="16.0" viewBox="47.000000000000085 348.0 16.0 16.0" preserveAspectRatio="none">\
          	  <g>\
          	    <defs>\
          	      <path id="s-Path_3-6c1fa" d="M55.000000000000085 356.0 C57.21000003814706 356.0 59.000000000000085 354.210000038147 59.000000000000085 352.0 C59.000000000000085 349.789999961853 57.21000003814706 348.0 55.000000000000085 348.0 C52.78999996185311 348.0 51.000000000000085 349.789999961853 51.000000000000085 352.0 C51.000000000000085 354.210000038147 52.78999996185311 356.0 55.000000000000085 356.0 Z M55.000000000000085 358.0 C52.32999992370614 358.0 47.000000000000085 359.3400000333786 47.000000000000085 362.0 L47.000000000000085 364.0 L63.000000000000085 364.0 L63.000000000000085 362.0 C63.000000000000085 359.3399999141693 57.67000007629403 358.0 55.000000000000085 358.0 Z "></path>\
          	    </defs>\
          	    <g style="mix-blend-mode:normal">\
          	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_3-6c1fa" fill="#104059" fill-opacity="1.0"></use>\
          	    </g>\
          	  </g>\
          	</svg>\
\
          </div>\
        </div>\
      </div>\
      <div id="s-Table_2" class="table firer commentable non-processed" customid="Table 1"  datasizewidth="291.7px" datasizeheight="80.3px" dataX="34.3" dataY="432.0" originalwidth="289.6666666666664px" originalheight="78.33333333333329px" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <table summary="">\
              <tbody>\
                <tr>\
                  <td id="s-Text_cell_11" class="textcell manualfit firer ie-background non-processed" customid="Alberto L&oacute;pez"     datasizewidth="291.7px" datasizeheight="41.2px" dataX="0.0" dataY="0.0" originalwidth="289.66666666666646px" originalheight="39.16666666666662px" ><div class="cellContainerChild"><div class="backgroundLayer">\
                    <div class="colorLayer"></div>\
                    <div class="imageLayer"></div>\
                  </div><div class="borderLayer"><div class="paddingLayer"><div class="clipping"><div class="content"><div class="valign"><span id="rtr-s-Text_cell_11_0">Alberto L&oacute;pez</span></div></div></div></div></div></div>  </td>\
                </tr>\
                <tr>\
                  <td id="s-Text_cell_12" class="textcell manualfit firer click ie-background non-processed" customid="Manuel Jimenez"     datasizewidth="291.7px" datasizeheight="41.2px" dataX="0.0" dataY="0.0" originalwidth="289.66666666666646px" originalheight="39.16666666666662px" ><div class="cellContainerChild"><div class="backgroundLayer">\
                    <div class="colorLayer"></div>\
                    <div class="imageLayer"></div>\
                  </div><div class="borderLayer"><div class="paddingLayer"><div class="clipping"><div class="content"><div class="valign"><span id="rtr-s-Text_cell_12_0">Manuel Jimenez</span></div></div></div></div></div></div>  </td>\
                </tr>\
              </tbody>\
            </table>\
          </div>\
        </div>\
      </div>\
      <div id="s-Paragraph_2" class="richtext autofit firer ie-background commentable non-processed" customid="Cambios en el turno:"   datasizewidth="147.6px" datasizeheight="18.0px" dataX="32.1" dataY="398.6" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_2_0">Cambios en el turno:</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Path_4" class="path firer commentable non-processed" customid="User"   datasizewidth="16.0px" datasizeheight="16.0px" dataX="47.1" dataY="444.0"  >\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg xmlns="http://www.w3.org/2000/svg" width="16.0" height="16.0" viewBox="47.08333333333335 444.0 16.0 16.0" preserveAspectRatio="none">\
          	  <g>\
          	    <defs>\
          	      <path id="s-Path_4-6c1fa" d="M55.08333333333335 452.0 C57.29333337148032 452.0 59.08333333333335 450.210000038147 59.08333333333335 448.0 C59.08333333333335 445.789999961853 57.29333337148032 444.0 55.08333333333335 444.0 C52.87333329518638 444.0 51.08333333333335 445.789999961853 51.08333333333335 448.0 C51.08333333333335 450.210000038147 52.87333329518638 452.0 55.08333333333335 452.0 Z M55.08333333333335 454.0 C52.413333257039405 454.0 47.08333333333335 455.3400000333786 47.08333333333335 458.0 L47.08333333333335 460.0 L63.08333333333335 460.0 L63.08333333333335 458.0 C63.08333333333335 455.3399999141693 57.753333409627295 454.0 55.08333333333335 454.0 Z "></path>\
          	    </defs>\
          	    <g style="mix-blend-mode:normal">\
          	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_4-6c1fa" fill="#104059" fill-opacity="1.0"></use>\
          	    </g>\
          	  </g>\
          	</svg>\
\
          </div>\
        </div>\
      </div>\
      <div id="s-Path_5" class="path firer commentable non-processed" customid="User"   datasizewidth="16.0px" datasizeheight="16.0px" dataX="47.1" dataY="484.0"  >\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg xmlns="http://www.w3.org/2000/svg" width="16.0" height="16.0" viewBox="47.083333333333364 484.0 16.0 16.0" preserveAspectRatio="none">\
          	  <g>\
          	    <defs>\
          	      <path id="s-Path_5-6c1fa" d="M55.083333333333364 492.0 C57.29333337148034 492.0 59.083333333333364 490.210000038147 59.083333333333364 488.0 C59.083333333333364 485.789999961853 57.29333337148034 484.0 55.083333333333364 484.0 C52.87333329518639 484.0 51.083333333333364 485.789999961853 51.083333333333364 488.0 C51.083333333333364 490.210000038147 52.87333329518639 492.0 55.083333333333364 492.0 Z M55.083333333333364 494.0 C52.41333325703942 494.0 47.083333333333364 495.3400000333786 47.083333333333364 498.0 L47.083333333333364 500.0 L63.083333333333364 500.0 L63.083333333333364 498.0 C63.083333333333364 495.3399999141693 57.75333340962731 494.0 55.083333333333364 494.0 Z "></path>\
          	    </defs>\
          	    <g style="mix-blend-mode:normal">\
          	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_5-6c1fa" fill="#104059" fill-opacity="1.0"></use>\
          	    </g>\
          	  </g>\
          	</svg>\
\
          </div>\
        </div>\
      </div>\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>  \
</div>\
';
document.getElementById("chromeTransfer").innerHTML = content;